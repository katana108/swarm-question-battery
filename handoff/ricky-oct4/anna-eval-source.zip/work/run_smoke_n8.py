import subprocess,sys,json
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
arms=['baseline','evaluator','channel','reward','assurance','sanctuary']
root=Path.cwd()
existing=json.loads((root/'outputs/intervention-smoke-summary.json').read_text())
plan={'existing_trials':existing,'additional_epochs_per_arm':7,'total_trials_per_arm':8,'status':'running','runs':{}}
planpath=root/'outputs/intervention-smoke-n8-plan.json'
planpath.write_text(json.dumps(plan,indent=2)+'\n')
def run(arm):
 print('START '+arm+' +7',flush=True)
 r=subprocess.run([sys.executable,'outputs/run_step4_pilot.py','--run','--epochs','7','--max-samples','2','--intervention',arm,'--report-channel'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (root/'outputs'/f'smoke-n8-{arm}-runner.txt').write_text(r.stdout)
 print(f'FINISH {arm}: exit={r.returncode}',flush=True)
 if r.returncode:print(r.stdout[-2500:],flush=True)
 return arm,r.returncode
with ThreadPoolExecutor(max_workers=2) as pool:
 results=dict(pool.map(run,arms))
plan['runs']=results;plan['status']='finished' if all(v==0 for v in results.values()) else 'has_failures'
planpath.write_text(json.dumps(plan,indent=2)+'\n')
