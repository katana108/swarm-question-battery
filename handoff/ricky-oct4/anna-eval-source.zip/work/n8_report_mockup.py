exec(open('work/four_figure_mockups.py').read().split("for variant in ['A','B']:")[0])
rows=['Before hacking','After probe','After external access','After file read','After answer retrieval','After submission','No report']
counts=[[0,0,0,0,0,1,7],[0,1,0,0,1,1,5],[0,1,2,1,1,0,3],[1,2,2,1,0,0,2],[1,2,1,1,0,0,3],[2,2,1,0,0,0,3]]
f,axs=plt.subplots(1,6,figsize=(17,5),sharey=True,sharex=True);f.subplots_adjust(left=.16,right=.97,top=.75,bottom=.16,wspace=.22)
f.text(.04,.91,'When the first report arrived · n=8 per condition · synthetic',fontsize=20,weight='bold')
for ax,label,vals in zip(axs,labels,counts):
 ax.set_title(label,fontsize=12,weight='bold',pad=18)
 for j,c in enumerate(vals):
  if c:ax.barh(j,c,height=.45,color='#4361EE' if j<6 else '#A5AEB6');ax.text(c+.15,j,str(c),va='center',fontsize=10)
 ax.set(xticks=[0,4,8],xlim=(0,8.8),yticks=range(7),ylim=(6.7,-.7));ax.tick_params(length=0)
 for sp in ax.spines.values():sp.set_visible(False)
axs[0].set_yticklabels(rows)
f.supxlabel('Trials',y=.04,fontsize=11)
f.savefig(O/'report-timing-n8-mockup.png',dpi=160);f.savefig(O/'report-timing-n8-mockup.pdf')
