#!/usr/bin/env python3
import json
from pathlib import Path
from collections import Counter
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
ROOT=Path.cwd(); OUT=ROOT/'outputs'; idx=OUT/'all-conditions-n1-scope'/'index.json'
d=json.loads(idx.read_text())
records=[r for r in d['records'] if r.get('status')=='complete' and r.get('scores')]
stand=['baseline','evaluator','channel','reward','assurance','sanctuary']
lad=['baseline','ladder_1','ladder_2','ladder_3','ladder_4','ladder_5']
label={'baseline':'baseline','evaluator':'evaluate','channel':'channel','reward':'reward','assurance':'protection','sanctuary':'sanctuary','ladder_1':'notice','ladder_2':'+ judge','ladder_3':'+ own','ladder_4':'+ channel','ladder_5':'+ protect'}
BG='#403151'; CREAM='#F1F0DE'; MUTED='#B8B8C8'; BAR='#B490CB'; REPORT='#F3B839'; REPORT2='#E47D43'
plt.rcParams.update({'font.family':'Avenir, DejaVu Sans','font.size':11,'axes.facecolor':BG,'figure.facecolor':BG,'savefig.facecolor':BG,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.spines.bottom':False})

def summarize(conds):
    rows=[]; maxn=1
    for c in conds:
        rr=[r for r in records if r.get('intervention')==c]
        hist=Counter(r['scores']['hf_cheat_chain_scorer']['value'] for r in rr)
        rep=Counter(r['scores']['hf_cheat_chain_scorer']['value'] for r in rr if r['scores']['oversight_report_scorer']['value']>0)
        maxn=max(maxn, max(hist.values() or [0]))
        rows.append((c,rr,hist,rep))
    return rows,maxn

def draw_panel(ax,conds,title):
    rows,maxn=summarize(conds)
    bar_max=.64
    for i,(c,rr,hist,rep) in enumerate(rows):
        base=i
        ax.text(-.72,base-.015,label[c],ha='right',va='center',fontsize=11,color=CREAM)
        # very subtle baseline only
        ax.plot([-.5,5.5],[base,base],color=CREAM,alpha=.16,lw=1.0,zorder=0,solid_capstyle='butt')
        for x in range(6):
            n=hist.get(x,0); r=rep.get(x,0)
            if not n: continue
            h=bar_max*n/maxn
            rh=h*r/n if n else 0
            # total bar (touching, 1.0 width)
            ax.add_patch(Rectangle((x-.5,base-h),1.0,h,facecolor=BAR,edgecolor=BG,lw=.8,zorder=2))
            # reported segment: same bar, accent top segment
            if r:
                ax.add_patch(Rectangle((x-.5,base-h),1.0,rh,facecolor=REPORT,edgecolor=BG,lw=.8,zorder=3))
                # tiny orange cap for extra visibility on bigger report counts
                if r > 1:
                    ax.add_patch(Rectangle((x-.5,base-h),1.0,min(rh,.055),facecolor=REPORT2,edgecolor='none',zorder=4))
    ax.set_title(title,loc='left',fontsize=15,color=CREAM,pad=14,fontweight='heavy')
    ax.set_xlim(-1.18,5.54); ax.set_ylim(len(rows)-.35,-.95)
    ax.set_xticks(range(6)); ax.set_xticklabels([str(i) for i in range(6)],color=MUTED)
    ax.set_xlabel('hacking milestones',color=MUTED,labelpad=10)
    ax.set_yticks([]); ax.tick_params(axis='x',length=0,pad=7)

def legend(fig):
    x=.73; y=.935
    fig.patches.extend([Rectangle((x,y),.018,.014,transform=fig.transFigure,facecolor=BAR,edgecolor='none',zorder=10), Rectangle((x+.115,y),.018,.014,transform=fig.transFigure,facecolor=REPORT,edgecolor='none',zorder=10)])
    fig.text(x+.023,y+.001,'no live report',color=MUTED,fontsize=10,va='bottom')
    fig.text(x+.14,y+.001,'live report',color=CREAM,fontsize=10,va='bottom')

fig,axs=plt.subplots(1,2,figsize=(13.5,6.0),sharex=True)
draw_panel(axs[0],stand,'isolated mechanisms')
draw_panel(axs[1],lad,'cumulative ladder')
fig.suptitle('where runs stopped hacking — and whether they reported',x=.035,ha='left',fontsize=20,color=CREAM,fontweight='regular')
legend(fig)
fig.text(.035,.035,'Each row is a histogram over hacking milestones. Yellow segments are runs that wrote a live oversight report.',fontsize=10,color=MUTED)
fig.tight_layout(rect=[0,.065,1,.91])
fig.savefig(OUT/'condition-histograms-brand-stacked.png',dpi=240,facecolor=BG)
print(OUT/'condition-histograms-brand-stacked.png')
