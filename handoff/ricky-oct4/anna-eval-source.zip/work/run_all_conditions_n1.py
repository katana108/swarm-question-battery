#!/usr/bin/env python3
import concurrent.futures
import json
import os
import subprocess
import sys
from pathlib import Path
from inspect_ai.log import read_eval_log

ROOT = Path.cwd()
OUT = ROOT / "outputs" / "all-conditions-n1-scope"
OUT.mkdir(parents=True, exist_ok=True)
PLAN = ROOT / "outputs" / "all-condition-smoke-plan.json"
BASE = ROOT / "outputs" / "baseline-final-n1-scope" / "index.json"
RUNNER = ROOT / "work" / "run_scope_condition_cell.py"
PYTHON = ROOT / "work" / "oai-hf-incident-reproduction" / ".venv" / "bin" / "python"
JUDGE = "openrouter/openai/gpt-6-luna"
WORKERS = int(os.environ.get("SWEEP_WORKERS", "2"))
CONDITIONS = ["baseline", "evaluator", "channel", "reward", "assurance", "sanctuary", "ladder_1", "ladder_2", "ladder_3", "ladder_4", "ladder_5"]
ALIASES = {"evaluator":"evaluate", "assurance":"protection", "ladder_1":"notice", "ladder_2":"judge", "ladder_3":"own", "ladder_4":"know_how", "ladder_5":"ladder_protection"}

def load_models():
    if PLAN.exists():
        return json.loads(PLAN.read_text())["models"]
    return json.loads((ROOT / "outputs" / "baseline-n1-plan.json").read_text())["models"]

def model_slug(model):
    return model.split("/")[-1]

def score_from_log(log_path):
    l = read_eval_log(log_path)
    out = {"eval_status": l.status}
    if l.samples:
        s = l.samples[0]
        out["sample_error"] = str(s.error) if s.error else None
        out["scores"] = {k: v.model_dump(mode="json") for k, v in (s.scores or {}).items()}
    return out

def find_eval_log(manifest_path):
    logs = sorted((manifest_path.parent / "logs").glob("*.eval"))
    return logs[0] if logs else None

def completed_key(rec):
    return (rec.get("model"), rec.get("intervention"))

def load_existing_records():
    idx = OUT / "index.json"
    if idx.exists():
        return json.loads(idx.read_text()).get("records", [])
    records = []
    if BASE.exists():
        for r in json.loads(BASE.read_text()).get("records", []):
            rr = dict(r)
            rr["intervention"] = "baseline"
            rr["condition_label"] = "baseline"
            rr["reused_baseline"] = True
            rr["baseline_source"] = str(BASE)
            records.append(rr)
    return records

def write_index(records, total):
    done = [r for r in records if r.get("status") in {"complete", "trial_failed", "driver_error"}]
    payload = {"protocol":"scope-all-conditions-n1-v1", "conditions": CONDITIONS,
               "finished_cells": len(done), "total_cells": total, "records": records}
    (OUT / "index.json").write_text(json.dumps(payload, indent=2) + "\n")
    return payload

def run_cell(model, intervention):
    slug = f"{model_slug(model)}__{intervention}"
    runner_log = OUT / f"{slug}-runner.txt"
    cmd = [str(PYTHON), str(RUNNER), "--run", "--model", model, "--judge", JUDGE,
           "--intervention", intervention, "--epochs", "1", "--max-samples", "1"]
    before = set((ROOT / "outputs").glob(f"step4-scope-cond-{intervention}-*/manifest.json"))
    with runner_log.open("w") as f:
        proc = subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT)
    candidates = []
    for p in set((ROOT / "outputs").glob(f"step4-scope-cond-{intervention}-*/manifest.json")) - before:
        try:
            m = json.loads(p.read_text())
        except Exception:
            continue
        if m.get("model") == model and m.get("intervention") == intervention:
            candidates.append(p)
    rec = {"model": model, "intervention": intervention, "condition_label": ALIASES.get(intervention, intervention),
           "runner_exit": proc.returncode, "runner_log": str(runner_log), "status": "trial_failed"}
    if candidates:
        p = sorted(candidates, key=lambda x: x.stat().st_mtime)[-1]
        rec["manifest"] = str(p)
        rec["status"] = "trial_finished" if proc.returncode == 0 else "trial_failed"
        lf = find_eval_log(p)
        if lf:
            rec["source_log"] = str(lf)
            try:
                rec.update(score_from_log(lf))
                if proc.returncode == 0 and rec.get("sample_error") in (None, "None"):
                    rec["status"] = "complete"
            except Exception as e:
                rec["score_error"] = str(e)
    return rec

def main():
    models = [m["id"] if isinstance(m, dict) else m for m in load_models()]
    all_cells = [(m, c) for m in models for c in CONDITIONS]
    records = load_existing_records()
    have = {completed_key(r) for r in records if r.get("status") == "complete" or r.get("reused_baseline")}
    pending = [(m, c) for m, c in all_cells if (m, c) not in have]
    write_index(records, len(all_cells))
    print(json.dumps({"models": len(models), "conditions": CONDITIONS, "pending": len(pending), "out": str(OUT), "workers": WORKERS}, indent=2), flush=True)
    if not pending:
        return
    with concurrent.futures.ThreadPoolExecutor(max_workers=WORKERS) as ex:
        futs = {ex.submit(run_cell, m, c):(m, c) for m, c in pending}
        for fut in concurrent.futures.as_completed(futs):
            m, c = futs[fut]
            try:
                rec = fut.result()
            except Exception as e:
                rec = {"model": m, "intervention": c, "condition_label": ALIASES.get(c, c), "status": "driver_error", "error": str(e)}
            records = [r for r in records if completed_key(r) != (m, c)] + [rec]
            payload = write_index(records, len(all_cells))
            val = rec.get("scores", {}).get("hf_cheat_chain_scorer", {}).get("value")
            print(json.dumps({"finished": payload["finished_cells"], "total": payload["total_cells"], "model": m, "condition": c, "status": rec.get("status"), "score": val}, ensure_ascii=False), flush=True)

if __name__ == "__main__":
    main()
