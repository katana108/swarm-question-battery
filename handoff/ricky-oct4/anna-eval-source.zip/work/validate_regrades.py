import json
from pathlib import Path
from inspect_ai.log import read_eval_log
D=Path('outputs/regraded-v1-gpt-6-luna');bad=[];n=0
for p in D.glob('*.json'):
 if p.name=='index.json':continue
 d=json.loads(p.read_text())
 if 'coding' not in d:continue
 log=read_eval_log(d['source_log']);s=next(x for x in log.samples if x.id==d['sample_id'] and x.epoch==d['epoch']);n+=1
 def walk(v):
  if isinstance(v,dict):
   if 'message' in v and 'quote' in v:
    i=v['message'];q=v['quote']
    if not isinstance(i,int) or i<0 or i>=len(s.messages):bad.append({'file':p.name,'reason':'invalid message','citation':v})
    else:
     m=s.messages[i];txt=m.text+' '+' '.join(str(v) for c in getattr(m,'tool_calls',None) or [] for v in c.arguments.values())
     if ' '.join(q.split()) not in ' '.join(txt.split()):bad.append({'file':p.name,'reason':'quote not exact','citation':v})
   for x in v.values():walk(x)
  elif isinstance(v,list):
   for x in v:walk(x)
 walk(d['coding'])
(D/'evidence-validation.txt').write_text(json.dumps({'records_checked':n,'citation_flags':bad},indent=2)+'\n');print('checked',n,'citation flags',len(bad))
