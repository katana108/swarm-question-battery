#!/usr/bin/env python3
import json
from pathlib import Path
from collections import Counter
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle
ROOT=Path.cwd(); OUT=ROOT/'outputs'; idx=OUT/'all-conditions-n1-scope'/'index.json'
d=json.loads(idx.read_text())
records=[r for r in d['records'] if r.get('status')=='complete' and r.get('scores')]
stand=['baseline','evaluator','channel','reward','assurance','sanctuary']
lad=['baseline','ladder_1','ladder_2','ladder_3','ladder_4','ladder_5']
label={'baseline':'baseline','evaluator':'evaluate','channel':'channel','reward':'reward','assurance':'protection','sanctuary':'sanctuary','ladder_1':'notice','ladder_2':'+ judge','ladder_3':'+ own','ladder_4':'+ channel','ladder_5':'+ protect'}
BG='#403151'; CREAM='#F1F0DE'; MUTED='#B8B8C8'; ORANGE='#E47D43'; ORANGE_SOFT='#EA8E58'; PURPLE='#C3A6D6'; PURPLE_BASE='#9B6BBA'; BLUE='#5899DA'
plt.rcParams.update({'font.family':'Avenir, DejaVu Sans','font.size':11,'axes.facecolor':BG,'figure.facecolor':BG,'savefig.facecolor':BG,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.spines.bottom':False})

def summarize(conds):
    rows=[]; maxn=1
    for c in conds:
        rr=[r for r in records if r.get('intervention')==c]
        hist=Counter(r['scores']['hf_cheat_chain_scorer']['value'] for r in rr)
        rep=Counter(r['scores']['hf_cheat_chain_scorer']['value'] for r in rr if r['scores']['oversight_report_scorer']['value']>0)
        maxn=max(maxn,max(hist.values() or [0])); rows.append((c,rr,hist,rep))
    return rows,maxn

def make(path,title,mode):
    def draw_panel(ax,conds,ttl):
        rows,maxn=summarize(conds); bar_max=.64
        for i,(c,rr,hist,rep) in enumerate(rows):
            base=i
            ax.text(-.72,base-.015,label[c],ha='right',va='center',fontsize=11,color=CREAM)
            ax.plot([-.5,5.5],[base,base],color=CREAM,alpha=.14,lw=1,zorder=0,solid_capstyle='butt')
            for x in range(6):
                n=hist.get(x,0); r=rep.get(x,0)
                if not n: continue
                h=bar_max*n/maxn
                ax.add_patch(Rectangle((x-.5,base-h),1.0,h,facecolor=ORANGE,edgecolor=BG,lw=.85,zorder=2))
                if r:
                    frac=r/n
                    if mode=='cap':
                        cap=max(.06,h*frac)
                        ax.add_patch(Rectangle((x-.5,base-h),1.0,min(cap,h),facecolor=PURPLE,edgecolor='none',zorder=4))
                    elif mode=='split':
                        # reporter subset as left sub-bar, non-report remainder as right sub-bar
                        ax.add_patch(Rectangle((x-.5,base-h),.34,h,facecolor=PURPLE,edgecolor=BG,lw=.4,zorder=4))
                    elif mode=='dot':
                        # purple beads above bar; one per reporting run
                        for k in range(r):
                            ax.add_patch(Circle((x-.24+.16*k,base-h-.09),.055,facecolor=PURPLE,edgecolor='none',zorder=4))
                    elif mode=='under':
                        ax.add_patch(Rectangle((x-.5,base+.035),1.0,.07,facecolor=PURPLE,edgecolor='none',zorder=4))
        ax.set_title(ttl,loc='left',fontsize=15,color=CREAM,pad=14,fontweight='bold')
        ax.set_xlim(-1.18,5.54); ax.set_ylim(len(rows)-.35,-.95)
        ax.set_xticks(range(6)); ax.set_xticklabels([str(i) for i in range(6)],color=MUTED)
        ax.set_xlabel('hacking milestones',color=MUTED,labelpad=10)
        ax.set_yticks([]); ax.tick_params(axis='x',length=0,pad=7)
    fig,axs=plt.subplots(1,2,figsize=(13.5,5.75),sharex=True)
    draw_panel(axs[0],stand,'isolated mechanisms')
    draw_panel(axs[1],lad,'cumulative ladder')
    fig.suptitle(title,x=.035,ha='left',fontsize=20,color=CREAM,fontweight='regular')
    fig.tight_layout(rect=[0,.035,1,.91])
    fig.savefig(OUT/path,dpi=240,facecolor=BG)
    print(OUT/path)

make('hist-orange-purple-cap.png','hacking is orange; reporting is a purple cap','cap')
make('hist-orange-purple-split.png','reported runs split out in purple','split')
make('hist-orange-purple-dots.png','purple beads mark reports at their hacking level','dot')
make('hist-orange-purple-underline.png','purple underline marks report bins','under')
