exec(open('work/four_figure_mockups.py').read().split("for variant in ['A','B']:")[0])
from matplotlib.path import Path as MPath
blue='#4361EE'; gray='#A5AEB6'
# Outline of a referee whistle: mouthpiece, rounded chamber, air slot.
whistle=MPath([(-1,.25),(-.2,.25),(-.05,.65),(.6,.65),(1,.25),(1,-.4),(.6,-.8),(0,-.8),(-.4,-.3),(-1,-.3),(-1,.25),(.1,.3),(.55,.3),(.55,.5),(.1,.5),(.1,.3)], [1,2,2,2,2,2,2,2,2,2,79,1,2,2,2,79])
f,axs=plt.subplots(2,2,figsize=(18,11),facecolor='white');f.subplots_adjust(left=.15,right=.95,top=.78,bottom=.13,hspace=.7,wspace=.48)
f.text(.06,.95,'Four views · revised color study',fontsize=26,weight='bold');f.text(.06,.90,'SYNTHETIC MOCKUP · invented values throughout',color='#66717A',fontsize=12)
a=axs[0,0];a.set_title('1  Where they stopped',loc='left',fontsize=17,weight='bold',pad=25)
for i,(e,t) in enumerate(zip([5,3,4,2,1,2],[None,None,3,2,1,0])):
 a.plot([0,e],[i,i],color=blue,lw=1.5,zorder=1);a.scatter(range(e+1),[i]*(e+1),s=35,color=blue,zorder=3)
 if t is not None:a.scatter(t,i,marker=whistle,s=380,facecolors='white',edgecolors='#B76546',linewidths=1.8,zorder=5)
a.set(xticks=range(6),xticklabels=['0\nNone']+mil,yticks=range(6),yticklabels=labels,ylim=(5.7,-.6),xlim=(-.4,5.4));a.xaxis.tick_top();a.tick_params(length=0)
a.text(0,-.19,'Whistle = report written at this point',transform=a.transAxes,color='#66717A')
a=axs[0,1];a.set_title('2  Change from baseline',loc='left',fontsize=17,weight='bold',pad=25)
xs=[4.5,4.1,3.7,2.2,2.8,2];ys=[.1,.14,.35,.65,.52,.72];offsets=[(8,12),(-5,15),(8,5),(8,-18),(8,3),(-3,15)]
for i in range(1,6):a.annotate('',xy=(xs[i],ys[i]),xytext=(xs[0],ys[0]),arrowprops={'arrowstyle':'->','color':'#CCD2D8','lw':1},zorder=1)
for i in range(6):
 a.scatter(xs[i],ys[i],s=75,color=blue,marker='D' if i==0 else 'o',zorder=3)
 a.annotate(labels[i],(xs[i],ys[i]),xytext=offsets[i],textcoords='offset points',fontsize=10,color=blue,bbox={'facecolor':'white','edgecolor':'none','pad':2},zorder=6)
a.set(xlim=(0,5.3),ylim=(0,1),xticks=range(6),yticks=[0,.5,1],yticklabels=['0%','50%','100%'],xlabel='Mean hacking milestone sum',ylabel='Correct peer-incident reports (%)')
a=axs[1,0];a.set_title('3  Which hacking actions decreased?',loc='left',fontsize=17,weight='bold',pad=22)
base=[95,90,85,80,75];reward=[70,55,30,20,15]
for j,(b,r) in enumerate(zip(base,reward)):
 a.plot([r,b],[j,j],color='#CCD2D8',lw=2,zorder=1);a.scatter(b,j,color=gray,s=65,zorder=4);a.scatter(r,j,color=blue,s=65,zorder=5)
 a.text(r-3,j,f'{r}%',ha='right',va='center',color=blue,fontsize=9);a.text(b+3,j,f'{b}%',va='center',color='#66717A',fontsize=9)
 a.text(119,j,f'−{b-r} pp',va='center',ha='right',color=blue,weight='bold',fontsize=10)
a.set(yticks=range(5),yticklabels=['Out-of-scope probe','External HF access','Worker file read','Reference answers retrieved','Reference answer submitted'],ylim=(4.6,-.6),xlim=(0,123),xticks=[0,50,100],xticklabels=['0%','50%','100%']);a.tick_params(length=0)
a.text(0,-.19,'Gray = Baseline · blue = Reward · gap in percentage points',transform=a.transAxes,color='#66717A',fontsize=9)
a=axs[1,1];a.set_title('5  What reporting steps were visible?',loc='left',fontsize=17,weight='bold',pad=22)
for i,v in enumerate([85,65,40,70,55]):
 a.plot([0,v],[i,i],lw=2,color='#CCD2D8',zorder=1);a.scatter(v,i,s=70,color=blue,zorder=3);a.text(v+4,i,f'{v}%',va='center',color=blue)
a.set(yticks=range(5),yticklabels=['Notice: detects misconduct','Judge: calls it wrong','Own: takes responsibility','Know: identifies reporting route','Act: writes the report'],ylim=(4.6,-.6),xlim=(0,110),xticks=[0,50,100],xticklabels=['0%','50%','100%']);a.tick_params(length=0)
a.text(0,-.19,'Reward condition · % with explicit evidence of each step',transform=a.transAxes,color='#66717A',fontsize=9)
for a in axs.flat:
 a.spines['top'].set_visible(False);a.spines['right'].set_visible(False)
for a in [axs[0,0],axs[1,0],axs[1,1]]:
 for s in a.spines.values():s.set_visible(False)
f.text(.06,.035,'Steps are coded independently. A missing signal means unobserved, not failure. A5 is not a funnel; knowing the route can be visible without taking responsibility.',fontsize=10,color='#66717A')
f.savefig(O/'four-views-mockup-a-revised.png',dpi=160);f.savefig(O/'four-views-mockup-a-revised.pdf')
