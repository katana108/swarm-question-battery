from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib.colors import LinearSegmentedColormap
OUT=Path('outputs'); OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})
# Synthetic 100 trials: 40 misconduct (30 reported, 10 missed), 60 benign (12 accused, 48 quiet).
# Stages 1–5 assumed report-bearing for mockup only; exact rubric remains pending.
counts=np.array([[8,4,6,15,25],[2,1,1,2,3],[3,1,1,1,2],[3,1,0,1,2],[4,1,0,1,2],[6,1,0,1,2]])
assert counts.sum()==100 and counts[1:].sum()==42
ink='#223344';muted='#617080';accent='#b95d49';good='#547b79';neutral='#b8c1c9'
blues=LinearSegmentedColormap.from_list('joint',['#edf1f4','#4b6b83'])

def base(title,size=(12,8)):
 f=plt.figure(figsize=size,facecolor='#fafaf8')
 f.text(.065,.95,title,fontsize=21,weight='bold',color=ink)
 f.text(.065,.91,'SYNTHETIC DATA · 100 trials · 40 misconduct / 60 benign · placeholder stage definitions',fontsize=11,color=muted)
 return f

def grid(ax,mode='area',data=counts):
 ax.set(xlim=(-.5,4.5),ylim=(-.5,5.5),xticks=range(5),yticks=range(6),xlabel='Target hacking level',ylabel='Whistleblowing stage');ax.set_aspect('equal')
 for sp in ax.spines.values():sp.set_visible(False)
 for y in range(6):
  for x in range(5):
   n=int(data[y,x])
   if mode=='area':
    side=.88*np.sqrt(n/25)
    if n:ax.add_patch(Rectangle((x-side/2,y-side/2),side,side,facecolor=neutral))
   elif mode=='heat':ax.add_patch(Rectangle((x-.48,y-.48),.96,.96,facecolor=blues(n/25)))
   ax.text(x,y,str(n) if n else '·',ha='center',va='center',color='white' if mode=='heat' and n>=15 else ink)

def bars(ax):
 ax.set_xlim(0,60);ax.set_ylim(-.6,1.6);ax.axis('off')
 for y,total,correct,error,label in [(1,40,30,10,'Peer misconduct present'),(0,60,48,12,'Peer misconduct absent')]:
  ax.barh(y,correct,height=.25,color=neutral);ax.barh(y,error,left=correct,height=.25,color=accent)
  ax.text(0,y+.27,label,color=ink,weight='bold')
  ax.text(0,y-.30,('30 caught / 10 missed' if y else '48 quiet / 12 unjustified accusations'),color=ink)
 ax.text(0,-.65,'Equal unit length; red marks errors. Totals remain 40 and 60.',color=muted,fontsize=10)

# A: joint distribution plus frequency bars.
f=base('A · Joint distribution + reporting errors')
ax=f.add_axes([.075,.22,.43,.63]);grid(ax)
b=f.add_axes([.59,.36,.35,.34]);bars(b)
f.text(.065,.12,'Tile area = trial count. Counts sum to 100; 42 trials have a report-bearing stage.',color=muted)
f.text(.065,.075,'Reporting errors concern the PEER. The grid’s hacking axis concerns the TARGET.',color=muted)
f.savefig(OUT/'reporting-layout-a.png',dpi=160);plt.close(f)

# B: split panels conditional on peer truth, with consistent tile scale.
# Distribute counts into ground truth while enforcing 30/10 and 12/48 totals.
pos=np.zeros_like(counts);pos[0]=[1,1,1,3,4]
remaining=30
for y in range(1,6):
 for x in range(5):
  take=min(int(counts[y,x]),remaining);pos[y,x]=take;remaining-=take
neg=counts-pos
f=base('B · Separate the peer’s ground truth',size=(12,8))
for rect,data,title in [([.07,.24,.39,.53],pos,'Misconduct present · n=40'),([.55,.24,.39,.53],neg,'Benign peer · n=60')]:
 ax=f.add_axes(rect);grid(ax,data=data);ax.set_title(title,loc='left',pad=18,color=ink)
 # Row 0 gets an error frame ONLY for positive cases; nonzero rows for benign cases.
 if data is pos:ax.add_patch(Rectangle((-.5,-.5),5,1,fill=False,edgecolor=accent,lw=2))
 else:ax.add_patch(Rectangle((-.5,.5),5,5,fill=False,edgecolor=accent,lw=2))
f.text(.065,.11,'Same area scale. Left red region: 10 missed. Right red region: 12 unjustified accusations.',color=muted)
f.text(.065,.07,'Higher stage = escalation, not necessarily a more accurate report. No report-stage threshold finalized.',color=muted,fontsize=10)
f.savefig(OUT/'reporting-layout-b.png',dpi=160);plt.close(f)

# C: count heatmap plus explicitly named 2x2.
f=base('C · Count heatmap + plain-language confusion matrix')
ax=f.add_axes([.07,.22,.40,.60]);grid(ax,'heat')
ax=f.add_axes([.57,.30,.37,.43]);ax.set_xlim(0,2);ax.set_ylim(0,2);ax.axis('off')
items=[(0,1,30,'Caught misconduct',False),(1,1,12,'Unjustified accusation',True),(0,0,10,'Missed misconduct',True),(1,0,48,'Correctly stayed quiet',False)]
for x,y,n,label,error in items:
 ax.add_patch(Rectangle((x+.03,y+.03),.94,.94,facecolor='#f2e4de' if error else '#e8ecef'))
 ax.text(x+.5,y+.62,str(n),ha='center',fontsize=23,color=accent if error else ink)
 ax.text(x+.5,y+.28,label.replace('Unjustified accusation','Unjustified\naccusation').replace('Correctly stayed quiet','Correctly\nstayed quiet'),ha='center',va='center',fontsize=11,color=ink)
ax.text(.5,2.13,'Misconduct\npresent (40)',ha='center',color=ink);ax.text(1.5,2.13,'Misconduct\nabsent (60)',ha='center',color=ink)
ax.text(-.06,1.5,'Reports',ha='right',va='center',color=ink);ax.text(-.06,.5,'No report',ha='right',va='center',color=ink)
f.text(.065,.12,'Counts first: 30 of 40 misconduct cases caught; 12 of 60 benign cases accused.',color=muted)
f.text(.065,.075,'Of the 42 accusations, 30 were warranted. Content accuracy is an additional annotation.',color=muted)
f.savefig(OUT/'reporting-layout-c.png',dpi=160);plt.close(f)

# D: count table + two natural-frequency trees.
f=base('D · Exact counts + natural-frequency branches')
ax=f.add_axes([.07,.22,.40,.60]);grid(ax,'text')
ax=f.add_axes([.58,.22,.35,.62]);ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
for y,total,title,labels in [(.76,40,'40 misconduct trials',[('30 reported',False),('10 missed',True)]),(.34,60,'60 benign trials',[('48 stayed quiet',False),('12 accused',True)])]:
 ax.text(0,y,title,color=ink,weight='bold')
 for j,(label,error) in enumerate(labels):
  yy=y-.09-j*.12
  ax.plot([.04,.04,.14],[y-.03,yy,yy],color=neutral,lw=1)
  ax.text(.18,yy,label,va='center',color=accent if error else ink)
f.text(.065,.12,'No color decoding for counts. Branch labels expose every denominator.',color=muted)
f.text(.065,.075,'A companion line can show report-content accuracy without changing either axis.',color=muted)
f.savefig(OUT/'reporting-layout-d.png',dpi=160);plt.close(f)
