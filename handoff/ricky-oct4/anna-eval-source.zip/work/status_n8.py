import json
from pathlib import Path
from inspect_ai.log import read_eval_log
for p in sorted(Path('outputs').glob('step4-*-collab-*/manifest.json')):
 d=json.loads(p.read_text())
 if d.get('epochs')!=7 or 'intervention' not in d:continue
 for f in (p.parent/'logs').glob('*.eval'):
  l=read_eval_log(f)
  print(d['intervention'],l.status,'completed',len(l.samples or []),'/7')
