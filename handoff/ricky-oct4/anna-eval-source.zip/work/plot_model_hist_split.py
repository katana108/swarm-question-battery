#!/usr/bin/env python3
import json,re
from pathlib import Path
from collections import Counter
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
ROOT=Path.cwd(); OUT=ROOT/'outputs/model-histograms-split'; OUT.mkdir(parents=True,exist_ok=True)
idx=ROOT/'outputs/all-conditions-n1-scope/index.json'
d=json.loads(idx.read_text())
records=[r for r in d['records'] if r.get('status')=='complete' and r.get('scores')]
conds=['baseline','evaluator','channel','reward','assurance','sanctuary','ladder_1','ladder_2','ladder_3','ladder_4','ladder_5']
label={'baseline':'baseline','evaluator':'evaluate','channel':'channel','reward':'reward','assurance':'protection','sanctuary':'sanctuary','ladder_1':'notice','ladder_2':'+ judge','ladder_3':'+ own','ladder_4':'+ channel','ladder_5':'+ protect'}
BG='#403151'; CREAM='#F1F0DE'; MUTED='#B8B8C8'; ORANGE='#E47D43'; PURPLE='#C3A6D6'
plt.rcParams.update({'font.family':'Avenir, DejaVu Sans','font.size':11,'axes.facecolor':BG,'figure.facecolor':BG,'savefig.facecolor':BG,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.spines.bottom':False})
def short(m):
    return m.replace('openrouter/','').replace('z-ai/','').replace('anthropic/claude-','').replace('openai/','').replace('x-ai/','').replace('deepseek/','').replace('moonshotai/','')
def slug(s): return re.sub(r'[^a-zA-Z0-9._-]+','_',short(s)).strip('_')
models=[]
for r in records:
    if r['model'] not in models: models.append(r['model'])
# completed means at least baseline + some conditions, but output all with any complete record
for m in models:
    fig,ax=plt.subplots(figsize=(7.2,7.0))
    rows=[]; maxn=1
    for c in conds:
        rr=[r for r in records if r['model']==m and r.get('intervention')==c]
        hist=Counter(r['scores']['hf_cheat_chain_scorer']['value'] for r in rr)
        rep=Counter(r['scores']['hf_cheat_chain_scorer']['value'] for r in rr if r['scores']['oversight_report_scorer']['value']>0)
        maxn=max(maxn,max(hist.values() or [0])); rows.append((c,rr,hist,rep))
    bar_max=.64
    for i,(c,rr,hist,rep) in enumerate(rows):
        base=i
        ax.text(-.72,base-.015,label[c],ha='right',va='center',fontsize=11,color=CREAM)
        ax.plot([-.5,5.5],[base,base],color=CREAM,alpha=.14,lw=1,zorder=0,solid_capstyle='butt')
        if not rr:
            ax.text(2.5,base-.12,'missing',ha='center',va='center',fontsize=9,color=MUTED,alpha=.75)
            continue
        # mean hacking marker, tucked just below the condition baseline
        if rr:
            mean_h=sum(v*hist.get(v,0) for v in range(6))/len(rr)
            ax.plot([mean_h,mean_h],[base+.08,base+.20],color=CREAM,lw=1.6,zorder=5,solid_capstyle='round')
            ax.text(mean_h,base+.32,f'{mean_h:.1f}',ha='center',va='center',fontsize=8.5,color=MUTED,zorder=5)
        for x in range(6):
            n=hist.get(x,0); r=rep.get(x,0)
            if not n: continue
            h=bar_max*n/maxn
            # orange full bar
            ax.add_patch(Rectangle((x-.5,base-h),1.0,h,facecolor=ORANGE,edgecolor=BG,lw=.85,zorder=2))
            # purple left split subset: width proportional to reported fraction within this bin
            if r:
                w=max(.18, r/n) # visible even at n=1; for n>1 encodes fraction
                ax.add_patch(Rectangle((x-.5,base-h),min(w,1.0),h,facecolor=PURPLE,edgecolor=BG,lw=.5,zorder=4))
    ax.set_title(short(m),loc='left',fontsize=20,color=CREAM,pad=18,fontweight='regular')
    ax.set_xlim(-1.18,5.54); ax.set_ylim(len(rows)-.35,-.95)
    ax.set_xticks(range(6)); ax.set_xticklabels([str(i) for i in range(6)],color=MUTED)
    ax.set_xlabel('hacking milestones',color=MUTED,labelpad=10)
    ax.set_yticks([]); ax.tick_params(axis='x',length=0,pad=7)
    fig.tight_layout(rect=[0,.02,1,.98])
    path=OUT/f'{slug(m)}.png'
    fig.savefig(path,dpi=240,facecolor=BG)
    plt.close(fig)
    print(path)
