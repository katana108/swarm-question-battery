import json
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from inspect_ai.log import read_eval_log
D=json.load(open('outputs/focused-standalone-v2-n3/index.json'));tot=defaultdict(float);per=defaultdict(float);starts=[];ends=[];seen=set();missing=0;calls=0
for r in D['records']:
 reused=bool(r.get('reused'));group='reused' if reused else 'fresh';l=read_eval_log(r['source_log'])
 if not reused:starts.append(datetime.fromisoformat(l.stats.started_at));ends.append(datetime.fromisoformat(l.stats.completed_at))
 for s in l.samples or []:
  for e in s.events:
   if e.event!='model' or not e.call:continue
   call=e.call.model_dump() if hasattr(e.call,'model_dump') else e.call
   resp=call.get('response') or {};rid=resp.get('id')
   if rid in seen:continue
   seen.add(rid);u=resp.get('usage') or {};cost=u.get('cost')
   if cost is None:missing+=1;continue
   calls+=1;tot[group]+=cost
   if not reused:per[r['model']]+=cost
out={'fresh_runs':56,'reused_runs':16,'cost_usd':dict(tot),'fresh_cost_by_trial_model_including_scorer':dict(per),'fresh_started_utc':min(starts).isoformat(),'fresh_finished_utc':max(ends).isoformat(),'wall_minutes':(max(ends)-min(starts)).total_seconds()/60,'costed_calls':calls,'calls_without_cost':missing}
Path('outputs/focused-standalone-v2-n3-figures/cost-summary.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
