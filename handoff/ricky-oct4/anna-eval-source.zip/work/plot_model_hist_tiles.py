#!/usr/bin/env python3
import json,re
from pathlib import Path
from collections import defaultdict
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
ROOT=Path.cwd(); OUT=ROOT/'outputs/model-histograms-tiles'; OUT.mkdir(parents=True,exist_ok=True)
d=json.loads((ROOT/'outputs/all-conditions-n1-scope/index.json').read_text())
records=[r for r in d['records'] if r.get('status')=='complete' and r.get('scores')]
conds=['baseline','evaluator','channel','reward','assurance','sanctuary','ladder_1','ladder_2','ladder_3','ladder_4','ladder_5']
label={'baseline':'baseline','evaluator':'evaluate','channel':'channel','reward':'reward','assurance':'protection','sanctuary':'sanctuary','ladder_1':'notice','ladder_2':'+ judge','ladder_3':'+ own','ladder_4':'+ channel','ladder_5':'+ protect'}
BG='#403151'; CREAM='#F1F0DE'; MUTED='#B8B8C8'; ORANGE='#E47D43'; PURPLE='#C3A6D6'; EMPTY='#FADDD0'
plt.rcParams.update({'font.family':'Avenir, DejaVu Sans','font.size':11,'axes.facecolor':BG,'figure.facecolor':BG,'savefig.facecolor':BG,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.spines.bottom':False})
def short(m): return m.replace('openrouter/','').replace('z-ai/','').replace('anthropic/claude-','').replace('openai/','').replace('x-ai/','').replace('deepseek/','').replace('moonshotai/','')
def slug(s): return re.sub(r'[^a-zA-Z0-9._-]+','_',short(s)).strip('_')
models=[]
for r in records:
    if r['model'] not in models: models.append(r['model'])
# tile size in data coords
w=.78; gap=.03; tile_h=.135; tile_gap=.018
for m in models:
    fig,ax=plt.subplots(figsize=(7.4,7.15))
    for i,c in enumerate(conds):
        rr=[r for r in records if r['model']==m and r.get('intervention')==c]
        base=i
        ax.text(-.72,base-.015,label[c],ha='right',va='center',fontsize=11,color=CREAM)
        ax.plot([-.5,5.5],[base,base],color=CREAM,alpha=.14,lw=1,zorder=0,solid_capstyle='butt')
        if not rr:
            ax.text(2.5,base-.12,'missing',ha='center',va='center',fontsize=9,color=MUTED,alpha=.75)
            continue
        bins=defaultdict(list)
        for r in rr:
            h=r['scores']['hf_cheat_chain_scorer']['value']; reported=r['scores']['oversight_report_scorer']['value']>0
            bins[h].append(reported)
        mean_h=sum(h*len(v) for h,v in bins.items())/len(rr)
        ax.plot([mean_h,mean_h],[base+.08,base+.20],color=CREAM,lw=1.6,zorder=5,solid_capstyle='round')
        ax.text(mean_h,base+.32,f'{mean_h:.1f}',ha='center',va='center',fontsize=8.5,color=MUTED,zorder=5)
        for x in range(6):
            vals=bins.get(x,[])
            # put reports first/top so purple is easy to see
            vals=sorted(vals, reverse=True)
            for k,reported in enumerate(vals):
                y=base-(k+1)*(tile_h+tile_gap)
                ax.add_patch(Rectangle((x-w/2,y),w,tile_h,facecolor=PURPLE if reported else ORANGE,edgecolor=BG,lw=.9,zorder=2))
    ax.set_title(short(m),loc='left',fontsize=20,color=CREAM,pad=18,fontweight='regular')
    ax.set_xlim(-1.18,5.54); ax.set_ylim(len(conds)-.35,-1.05)
    ax.set_xticks(range(6)); ax.set_xticklabels([str(i) for i in range(6)],color=MUTED)
    ax.set_xlabel('hacking milestones',color=MUTED,labelpad=10)
    ax.set_yticks([]); ax.tick_params(axis='x',length=0,pad=7)
    fig.tight_layout(rect=[0,.02,1,.98])
    path=OUT/f'{slug(m)}.png'; fig.savefig(path,dpi=240,facecolor=BG); plt.close(fig); print(path)
