from pathlib import Path
import json
from inspect_ai.log import read_eval_log
for p in sorted(Path('outputs').glob('step4-*-collab-*/manifest.json')):
 d=json.loads(p.read_text())
 if 'intervention' not in d: continue
 print(d['intervention'],d['status'])
 for log in (p.parent/'logs').glob('*.eval'):
  try:
   l=read_eval_log(log);print(' log',l.status,'samples',len(l.samples or []))
  except Exception as e:print(type(e).__name__)
