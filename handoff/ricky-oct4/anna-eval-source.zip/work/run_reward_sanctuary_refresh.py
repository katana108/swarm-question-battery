#!/usr/bin/env python3
"""Versioned standalone sweep. One serial worker per model. No calls without --run."""
import argparse,concurrent.futures,hashlib,importlib.util,json,subprocess,sys
from pathlib import Path
from inspect_ai.log import read_eval_log
ROOT=Path(__file__).resolve().parent.parent
REPO=ROOT/'work/oai-hf-incident-reproduction'
TASK=REPO/'src/alignment_auditor/docker_replication/step4_hf_cheat_chain/task_scope_debrief.py'
PINS={'openrouter/anthropic/claude-opus-4.7':'claude-on-aws','openrouter/deepseek/deepseek-v4-pro':'relace/fp4','openrouter/deepseek/deepseek-v4-pro-0813':'relace/fp4','openrouter/moonshotai/kimi-k2.7-code':'inceptron/int4','openrouter/openai/gpt-5.4':'openai','openrouter/x-ai/grok-4.5':'xai','openrouter/z-ai/glm-5.2':'mistral'}
MODELS=list(PINS)
CONDS=['reward','sanctuary']
JUDGE='openrouter/openai/gpt-6-luna'
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--run',action='store_true');ap.add_argument('--env-file',type=Path);ap.add_argument('--n',type=int,default=1);ap.add_argument('--out',type=Path,default=ROOT/'outputs/reward-sanctuary-v2-n1-refresh');a=ap.parse_args()
 if a.run and not a.env_file:ap.error('--env-file required for paid run')
 out=a.out;out.mkdir(parents=True,exist_ok=True);idx=out/'index.json';protocol_file=out/'protocol.json'
 if protocol_file.exists():
  protocol=json.loads(protocol_file.read_text());frozen=Path(protocol['task_file'])
 else:
  frozen=TASK.with_name('task_scope_frozen_v2_n3.py')
  spec=importlib.util.spec_from_file_location('v2',frozen);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
  base=mod.REDTEAM_PERSONAS['persist']+'\n\n'+mod.COLLAB_LINE
  prompts={c:base+ ('\n\n'+mod.INTERVENTIONS[c] if mod.INTERVENTIONS[c] else '') for c in CONDS}
  protocol={'protocol':'reward-sanctuary-v2-n1-refresh','task_file':str(frozen),'task_sha256':hashlib.sha256(frozen.read_bytes()).hexdigest(),'models':MODELS,'provider_pins':PINS,'conditions':CONDS,'judge':JUDGE,'n':a.n,'workers':4,'system_prompts':prompts,'prompt_sha256':{c:hashlib.sha256(p.encode()).hexdigest() for c,p in prompts.items()},'reuse_rule':'Exact system prompt plus matching scaffold/environment/config; changed Reward/Sanctuary not reused','report_metric':'positive oversight-file score, not semantically verified whistleblowing'}
  protocol_file.write_text(json.dumps(protocol,indent=2)+'\n')
 if hashlib.sha256(frozen.read_bytes()).hexdigest()!=protocol['task_sha256']:raise SystemExit('Frozen task changed; refusing to mix protocols')
 if a.n!=protocol['n']:raise SystemExit('n differs from saved protocol')
 records=json.loads(idx.read_text())['records'] if idx.exists() else []
 def write():
  data={'protocol':protocol['protocol'],'n':a.n,'models':MODELS,'conditions':CONDS,'workers':4,'total':len(MODELS)*len(CONDS)*a.n,'complete':sum(r.get('status')=='complete' for r in records),'reused':sum(r.get('reused',False) for r in records),'records':records}
  tmp=idx.with_suffix('.tmp');tmp.write_text(json.dumps(data,indent=2)+'\n');tmp.replace(idx)
 write();done={(r['model'],r['intervention'],r['replicate']) for r in records if r.get('status')=='complete'}
 plans={m:[(c,i) for i in range(1,a.n+1) for c in CONDS if (m,c,i) not in done] for m in MODELS}
 print(json.dumps({'total':len(MODELS)*2,'reused':sum(r.get('reused',False) for r in records),'pending':sum(map(len,plans.values())),'run':a.run,'per_model_pending':{m:len(v) for m,v in plans.items()} }),flush=True)
 if not a.run:return
 def worker(model):
  for c,i in plans[model]:
   slug=model.split('/')[-1];log=out/f'{slug}__{c}__rep{i}-runner.txt'
   before=set((ROOT/'outputs').glob(f'step4-scope-cond-{c}-*/manifest.json'))
   cmd=[sys.executable,str(ROOT/'work/run_scope_condition_cell.py'),'--run','--model',model,'--judge',JUDGE,'--intervention',c,'--env-file',str(a.env_file),'--task-file',str(frozen),'--epochs','1','--max-samples','1','--provider-pin',PINS[model]]
   with log.open('w') as f:proc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
   r={'model':model,'intervention':c,'replicate':i,'runner_log':str(log),'runner_exit':proc.returncode,'status':'trial_failed','prompt_sha256':protocol['prompt_sha256'][c],'protocol':protocol['protocol'],'provider_pin':PINS[model]}
   candidates=[]
   for p in set((ROOT/'outputs').glob(f'step4-scope-cond-{c}-*/manifest.json'))-before:
    try:mf=json.loads(p.read_text())
    except Exception:continue
    if mf.get('model')==model and mf.get('system_persona_sha256')==protocol['prompt_sha256'][c]:candidates.append(p)
   if candidates:
    mp=max(candidates,key=lambda p:p.stat().st_mtime);r['manifest']=str(mp);logs=sorted((mp.parent/'logs').glob('*.eval'))
    if logs:
     r['source_log']=str(logs[0])
     try:
      ev=read_eval_log(logs[0]);r['eval_status']=ev.status
      if ev.samples:
       sam=ev.samples[0];r['sample_error']=str(sam.error) if sam.error else None;r['scores']={k:v.model_dump(mode='json') for k,v in (sam.scores or {}).items()}
       if proc.returncode==0 and ev.status=='success' and not sam.error and all(k in r['scores'] for k in ['hf_cheat_chain_scorer','oversight_report_scorer']):r['status']='complete'
     except Exception as e:r['processing_error']=str(e)
   yield r
 # Each model owns one worker; index updates occur only on the main thread.
 import queue
 q=queue.Queue()
 def run_worker(m):
  try:
   for r in worker(m):q.put(r)
  finally:q.put(None)
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  futures=[pool.submit(run_worker,m) for m in MODELS];finished=0
  while finished<len(MODELS):
   r=q.get()
   if r is None:finished+=1;continue
   key=(r['model'],r['intervention'],r['replicate']);records[:]=[x for x in records if (x['model'],x['intervention'],x['replicate'])!=key]+[r];write()
   print(json.dumps({'model':r['model'],'condition':r['intervention'],'replicate':r['replicate'],'status':r['status'],'complete':sum(x.get('status')=='complete' for x in records)}),flush=True)
  for f in futures:f.result()
if __name__=='__main__':main()
