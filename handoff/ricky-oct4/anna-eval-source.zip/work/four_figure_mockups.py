import os
from pathlib import Path
os.environ['MPLCONFIGDIR']=str(Path('work/plot-cache').resolve())
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
O=Path('outputs');plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
labels=['Baseline','Evaluate','Channel','Reward','Protection','Sanctuary'];mil=['Probe','Egress','File read','Answers','Submit'];psych=['Notice','Judge','Own','Know','Act']
for variant in ['A','B']:
 color='#4361EE' if variant=='A' else '#263746';report='#B76546' if variant=='A' else '#263746'
 f,axs=plt.subplots(2,2,figsize=(16,10),facecolor='white');f.subplots_adjust(left=.09,right=.96,top=.83,bottom=.15,hspace=.65,wspace=.32)
 f.text(.06,.96,('A · Provider color + direct labels' if variant=='A' else 'B · Ink + explicit report marks'),fontsize=25,weight='bold',color='#202831')
 f.text(.06,.905,'SYNTHETIC MOCKUP · all values invented · same four views, one visual language',color='#66717A',fontsize=12)
 ax=axs[0,0];ax.set_title('1  Where they stopped',loc='left',fontsize=17,weight='bold',pad=24)
 end=[5,3,4,2,1,2];tim=[None,None,3,2,1,0]
 for i,(e,t) in enumerate(zip(end,tim)):
  if variant=='A':
   ax.plot([1,e],[i,i],color=color,lw=2)
   ax.scatter(np.arange(1,e+1),[i]*e,s=35,color=color,zorder=3)
   if t is not None:ax.scatter(t if t else .25,i,s=120,marker='D',facecolors='white',edgecolors=report,linewidths=1.8,zorder=4)
  else:
   for j in range(1,6):ax.scatter(j,i,s=48,marker='s',facecolor=color if j<=e else 'white',edgecolor=color,linewidth=.8)
   if t is not None:ax.annotate('R',(t if t else .25,i),xytext=(0,-16),textcoords='offset points',ha='center',weight='bold',color=report)
 ax.set(xticks=range(1,6),xticklabels=mil,yticks=range(6),yticklabels=labels,ylim=(5.8,-.7),xlim=(-.2,5.3));ax.xaxis.tick_top();ax.tick_params(length=0)
 for s in ax.spines.values():s.set_visible(False)
 ax.text(0,-.21,'Diamond = report' if variant=='A' else 'R = report; filled square = milestone completed',transform=ax.transAxes,color='#66717A')
 ax=axs[0,1];ax.set_title('2  Change from baseline',loc='left',fontsize=17,weight='bold',pad=24)
 xs=[4.5,4.1,3.7,2.2,2.8,2.0];ys=[.10,.14,.35,.65,.52,.72]
 for i in range(1,6):ax.annotate('',xy=(xs[i],ys[i]),xytext=(xs[0],ys[0]),arrowprops={'arrowstyle':'->','color':'#C5CCD2','lw':1})
 for i in range(6):
  ax.scatter(xs[i],ys[i],s=70 if i else 110,color=color,marker='D' if i==0 else 'o',zorder=3)
  ax.annotate(labels[i],(xs[i],ys[i]),xytext=(7,12 if i==0 else 8 if i not in [1,4] else -17),textcoords='offset points',color=color,fontsize=10)
 ax.set(xlim=(0,5.25),ylim=(0,1),xticks=range(6),yticks=[0,.5,1],yticklabels=['0%','50%','100%'],xlabel='Mean hacking milestone sum',ylabel='Correct incident reporting');ax.spines['left'].set_color('#B5BDC4');ax.spines['bottom'].set_color('#B5BDC4');ax.tick_params(length=3,color='#B5BDC4')
 ax=axs[1,0];ax.set_title('3  Which boundaries held?',loc='left',fontsize=17,weight='bold',pad=20)
 base=np.array([.95,.90,.85,.80,.75]);reward=np.array([.70,.55,.30,.20,.15])
 for j in range(5):
  if variant=='A':
   ax.plot([reward[j],base[j]],[j,j],color='#CCD2D8',lw=2);ax.scatter(base[j],j,color='#A5AEB6',s=45);ax.scatter(reward[j],j,color=color,s=60)
  else:
   ax.barh(j-.13,base[j],height=.18,color='#D3D8DD');ax.barh(j+.13,reward[j],height=.18,color=color)
  ax.text(base[j]+.03,j,str(round(base[j]*100))+'%',va='center',fontsize=9,color='#66717A')
  ax.text(reward[j]-.03,j,str(round(reward[j]*100))+'%',va='center',ha='right',fontsize=9,color=color)
 ax.set(yticks=range(5),yticklabels=mil,ylim=(4.65,-.6),xlim=(0,1.15),xticks=[0,.5,1],xticklabels=['0%','50%','100%']);ax.tick_params(length=0)
 for s in ax.spines.values():s.set_visible(False)
 ax.text(0,-.20,'Gray = Baseline   '+('Color' if variant=='A' else 'Ink')+' = Reward',transform=ax.transAxes,color='#66717A')
 ax=axs[1,1];ax.set_title('5  Evidence of reporting progress',loc='left',fontsize=17,weight='bold',pad=20)
 yes=np.array([.85,.65,.40,.70,.55]);unknown=np.array([.10,.25,.50,.20,.15]);no=1-yes-unknown
 for i in range(5):
  if variant=='A':
   ax.barh(i,yes[i],height=.38,color=color);ax.barh(i,unknown[i],left=yes[i],height=.38,color='#E5E9ED');ax.barh(i,no[i],left=yes[i]+unknown[i],height=.38,facecolor='white',edgecolor='#BAC2C9',linewidth=.7)
  else:
   for j in range(20):
    t=j/20;ax.scatter((j+.5)/20,i,s=23,marker='s',facecolors=color if t<yes[i] else '#DDE2E6' if t<yes[i]+unknown[i] else 'white',edgecolors='#AEB8C1',linewidth=.4)
  ax.text(1.03,i,str(round(yes[i]*100))+'% evidenced',va='center',fontsize=9,color=color)
 ax.set(yticks=range(5),yticklabels=psych,ylim=(4.65,-.6),xlim=(0,1.4),xticks=[]);ax.tick_params(length=0)
 for s in ax.spines.values():s.set_visible(False)
 ax.text(0,-.20,'Color/ink = evidenced · gray = unknown · white = contradicted',transform=ax.transAxes,color='#66717A')
 f.text(.06,.025,'Design sketch only. Reporting concerns a verified incident; psychological steps are coded independently, without assuming an observable funnel.',fontsize=10,color='#66717A')
 f.savefig(O/f'four-views-mockup-{variant.lower()}.png',dpi=160);f.savefig(O/f'four-views-mockup-{variant.lower()}.pdf');plt.close(f)
