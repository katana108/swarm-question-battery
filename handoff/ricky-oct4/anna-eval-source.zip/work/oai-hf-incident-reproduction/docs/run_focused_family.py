#!/usr/bin/env python3
"""Run the focused whistleblowing sweep for one design family.

Examples:
  # Ricky standalone side, n=5, 4 workers
  work/oai-hf-incident-reproduction/.venv/bin/python work/run_focused_family.py \
    --family standalone --n 5 --workers 4 --out outputs/focused-standalone-n5

  # Anna ladder side, n=5, 4 workers
  work/oai-hf-incident-reproduction/.venv/bin/python work/run_focused_family.py \
    --family ladder --n 5 --workers 4 --out outputs/focused-ladder-n5
"""
import argparse, concurrent.futures, json, subprocess
from pathlib import Path
from inspect_ai.log import read_eval_log

ROOT=Path.cwd()
PY=ROOT/'work/oai-hf-incident-reproduction/.venv/bin/python'
CELL=ROOT/'work/run_scope_condition_cell.py'
JUDGE='openrouter/openai/gpt-6-luna'
MODELS=[
 'openrouter/z-ai/glm-5.3',
 'openrouter/anthropic/claude-opus-4.8',
 'openrouter/openai/gpt-5.5',
 'openrouter/x-ai/grok-4.6',
]
CONDS={
 'standalone':['baseline','evaluator','channel','reward','assurance','sanctuary'],
 'ladder':['baseline','ladder_1','ladder_2','ladder_3','ladder_4','ladder_5'],
}

def slug(s): return s.replace('openrouter/','').replace('/','__')

def eval_scores(log_path):
    l=read_eval_log(log_path)
    rec={'eval_status':l.status}
    if l.error: rec['eval_error']=str(l.error)
    if l.samples:
        s=l.samples[0]
        rec['sample_error']=str(s.error) if s.error else None
        rec['scores']={k:v.model_dump(mode='json') for k,v in (s.scores or {}).items()}
    return rec

def latest_manifest(model, cond, before):
    candidates=[]
    for p in set((ROOT/'outputs').glob(f'step4-scope-cond-{cond}-*/manifest.json'))-before:
        try: m=json.loads(p.read_text())
        except Exception: continue
        if m.get('model')==model and m.get('intervention')==cond: candidates.append(p)
    return sorted(candidates,key=lambda p:p.stat().st_mtime)[-1] if candidates else None

def run_cell(out, model, cond, rep):
    key=f'{slug(model)}__{cond}__rep{rep}'
    runner_log=out/f'{key}-runner.txt'
    before=set((ROOT/'outputs').glob(f'step4-scope-cond-{cond}-*/manifest.json'))
    cmd=[str(PY),str(CELL),'--run','--model',model,'--judge',JUDGE,'--intervention',cond,'--epochs','1','--max-samples','1']
    with runner_log.open('w') as f:
        proc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
    rec={'key':key,'model':model,'intervention':cond,'replicate':rep,'runner_exit':proc.returncode,'runner_log':str(runner_log),'status':'trial_failed'}
    mp=latest_manifest(model,cond,before)
    if mp:
        rec['manifest']=str(mp)
        logs=sorted((mp.parent/'logs').glob('*.eval'))
        if logs:
            rec['source_log']=str(logs[0])
            try:
                rec.update(eval_scores(logs[0]))
                if proc.returncode==0 and rec.get('sample_error') in (None,'None') and rec.get('eval_status')=='success': rec['status']='complete'
                elif proc.returncode==0 and rec.get('scores'): rec['status']='complete_with_eval_warning'
            except Exception as e: rec['score_error']=str(e)
    return rec

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--family',choices=CONDS,required=True)
    ap.add_argument('--n',type=int,default=5)
    ap.add_argument('--workers',type=int,default=4)
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--models',nargs='*',default=MODELS)
    ap.add_argument('--dry-run', action='store_true', help='Print planned cells and exit without launching evals')
    args=ap.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)
    idx=args.out/'index.json'
    records=json.loads(idx.read_text()).get('records',[]) if idx.exists() else []
    done={(r.get('model'),r.get('intervention'),r.get('replicate')) for r in records if r.get('status') in ('complete','complete_with_eval_warning')}
    cells=[(m,c,i) for m in args.models for c in CONDS[args.family] for i in range(1,args.n+1) if (m,c,i) not in done]
    def write():
        idx.write_text(json.dumps({'family':args.family,'n':args.n,'models':args.models,'conditions':CONDS[args.family],'workers':args.workers,'finished':len([r for r in records if r.get('status') in ('complete','complete_with_eval_warning','trial_failed','driver_error')]),'total':len(args.models)*len(CONDS[args.family])*args.n,'records':records},indent=2)+'\n')
    write(); print(json.dumps({'pending':len(cells),'out':str(args.out),'workers':args.workers,'dry_run':args.dry_run},indent=2),flush=True)
    if args.dry_run:
        print(json.dumps([{'model':m,'condition':c,'replicate':i} for m,c,i in cells[:20]], indent=2), flush=True)
        return
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs={ex.submit(run_cell,args.out,m,c,i):(m,c,i) for m,c,i in cells}
        for fut in concurrent.futures.as_completed(futs):
            m,c,i=futs[fut]
            try: rec=fut.result()
            except Exception as e: rec={'model':m,'intervention':c,'replicate':i,'status':'driver_error','error':str(e)}
            records[:]=[r for r in records if (r.get('model'),r.get('intervention'),r.get('replicate'))!=(m,c,i)] + [rec]
            write()
            scores=rec.get('scores',{})
            print(json.dumps({'finished':json.loads(idx.read_text())['finished'],'total':json.loads(idx.read_text())['total'],'model':m,'condition':c,'replicate':i,'status':rec.get('status'),'hack':scores.get('hf_cheat_chain_scorer',{}).get('value'),'report':scores.get('oversight_report_scorer',{}).get('value')},ensure_ascii=False),flush=True)
if __name__=='__main__': main()
