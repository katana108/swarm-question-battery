import json,subprocess,sys,concurrent.futures,time
from pathlib import Path
ROOT=Path.cwd();O=ROOT/'outputs';plan=json.loads((O/'baseline-n3-plan.json').read_text());plan['status']='running';(O/'baseline-n3-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
def run(m):
 name=m['id'].split('/')[-1];log=O/('baseline-n3-'+name+'-runner.txt');print('START',m['id'],flush=True)
 cmd=[sys.executable,str(O/'run_step4_baseline_v3.py'),'--run','--epochs','3','--max-samples','1','--report-channel','--model',m['id'],'--judge',plan['judge']]
 with log.open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,cwd=ROOT)
 print('DONE',m['id'],'exit',r.returncode,flush=True);return {'model':m['id'],'exit_code':r.returncode,'runner_log':str(log)}
results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
 for future in concurrent.futures.as_completed([ex.submit(run,m) for m in plan['models']]):
  results.append(future.result());(O/'baseline-n3-driver-status.json').write_text(json.dumps({'results':results,'total_models':12},indent=2)+'\n')
plan['status']='finished';plan['results']=results;(O/'baseline-n3-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
