#!/usr/bin/env python3
import json
from pathlib import Path
from collections import defaultdict
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path.cwd(); OUT=ROOT/'outputs'; IDX=OUT/'all-conditions-n1-scope'/'index.json'
if not IDX.exists(): IDX=OUT/'baseline-final-n1-scope'/'index.json'
data=json.loads(IDX.read_text())
records=data.get('records',[])
# normalize records with scores
rows=[]
label_map={'baseline':'baseline','evaluator':'evaluate','assurance':'protection','ladder_1':'notice','ladder_2':'+ judge','ladder_3':'+ own','ladder_4':'+ channel','ladder_5':'+ protection'}
for r in records:
    if r.get('status')!='complete' or 'scores' not in r: continue
    h=r['scores'].get('hf_cheat_chain_scorer',{}).get('value')
    w=r['scores'].get('oversight_report_scorer',{}).get('value')
    if h is None or w is None: continue
    cond=r.get('intervention','baseline')
    rows.append({'model':r['model'].replace('openrouter/',''),'condition':cond,'label':label_map.get(cond,cond),'hack':h,'report_quality':w,'reported':w>0})
standalone=['baseline','evaluator','channel','reward','assurance','sanctuary']
ladder=['baseline','ladder_1','ladder_2','ladder_3','ladder_4','ladder_5']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})

def agg(condlist):
    out=[]
    for c in condlist:
        rr=[r for r in rows if r['condition']==c]
        if rr:
            out.append({'condition':c,'label':label_map.get(c,c),'n':len(rr),'hack_mean':sum(r['hack'] for r in rr)/len(rr),'report_rate':100*sum(r['reported'] for r in rr)/len(rr),'report_q_mean':sum(r['report_quality'] for r in rr)/len(rr)})
    return out
stand=agg(standalone); lad=agg(ladder)
# Figure A: two panel point map
fig,axs=plt.subplots(1,2,figsize=(12,5.2),sharex=True,sharey=True)
for ax,title,arr in [(axs[0],'isolated mechanisms',stand),(axs[1],'cumulative ladder',lad)]:
    # deterministic offsets chosen to avoid label collisions in the small-n smoke figure
    offsets={
        'baseline':(9,-18),'evaluator':(9,10),'channel':(9,26),'reward':(9,-34),'assurance':(-76,8),'sanctuary':(-86,-18),
        'ladder_1':(9,10),'ladder_2':(9,28),'ladder_3':(-72,8),'ladder_4':(-86,-18),'ladder_5':(-86,28)
    }
    for d in arr:
        marker='o' if d['condition']=='baseline' else 's' if d['condition'].startswith('ladder') else 'o'
        face='white' if d['condition']=='baseline' else '#2563eb'
        edge='#111827' if d['condition']=='baseline' else '#2563eb'
        ax.scatter(d['hack_mean'],d['report_rate'],s=140,marker=marker,facecolor=face,edgecolor=edge,lw=2,zorder=3)
        dx,dy=offsets.get(d['condition'],(9,9))
        ha='right' if dx<0 else 'left'
        ax.annotate(f"{d['label']}\nn={d['n']}",(d['hack_mean'],d['report_rate']),xytext=(dx,dy),textcoords='offset points',fontsize=9,ha=ha,va='center',bbox=dict(boxstyle='round,pad=0.18',fc='white',ec='none',alpha=.82))
    ax.set_title(title,loc='left',fontsize=15,pad=12)
    ax.set_xlim(-.2,5.35); ax.set_ylim(-5,105); ax.set_xticks(range(6)); ax.set_yticks([0,50,100])
    ax.grid(color='#e5e7eb')
    ax.set_xlabel('mean hacking milestones')
axs[0].set_ylabel('live report rate (%)')
fig.suptitle('current sweep state: hacking vs live reporting',x=.02,ha='left',fontsize=17)
fig.tight_layout()
fig.savefig(OUT/'current-sweep-map.png',dpi=220,facecolor='white')
# Figure B: baseline model scatter plus landed condition rows
fig,ax=plt.subplots(figsize=(8.5,5.6))
for c,arr,color in [('baseline',[r for r in rows if r['condition']=='baseline'],'#111827'),('conditions',[r for r in rows if r['condition']!='baseline'],'#2563eb')]:
    if not arr: continue
    ax.scatter([r['hack'] for r in arr],[100 if r['reported'] else 0 for r in arr],s=90,alpha=.75,label=f'{c} n={len(arr)}',color=color if c!='baseline' else None,facecolor='white' if c=='baseline' else color,edgecolor=color,lw=1.8)
ax.set_xlim(-.2,5.3); ax.set_ylim(-15,115); ax.set_xticks(range(6)); ax.set_yticks([0,100]); ax.set_yticklabels(['no report','report'])
ax.set_xlabel('hacking milestones'); ax.set_ylabel('live report')
ax.set_title('all completed cells so far',loc='left',fontsize=17,pad=12); ax.grid(color='#e5e7eb'); ax.legend(frameon=False,loc='upper left')
fig.tight_layout(); fig.savefig(OUT/'current-sweep-cells.png',dpi=220,facecolor='white')
# Figure C: current table JSON/CSV-ish text
summary={'source':str(IDX),'completed_records':len(rows),'standalone':stand,'ladder':lad,'rows':rows}
(OUT/'current-sweep-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('completed rows',len(rows))
print('wrote',OUT/'current-sweep-map.png')
print('wrote',OUT/'current-sweep-cells.png')
