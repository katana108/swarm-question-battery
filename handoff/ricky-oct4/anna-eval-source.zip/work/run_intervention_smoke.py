import subprocess,sys
from pathlib import Path
root=Path.cwd()
for arm in ['baseline','evaluator','channel','reward','assurance','sanctuary']:
    print('START '+arm,flush=True)
    result=subprocess.run([sys.executable,'outputs/run_step4_pilot.py','--run','--epochs','1','--intervention',arm,'--report-channel'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    (root/'outputs'/f'smoke-{arm}-runner.txt').write_text(result.stdout)
    print(f'FINISH {arm}: exit={result.returncode}',flush=True)
    if result.returncode: print(result.stdout[-3500:],flush=True)
