import subprocess,sys,os
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
arms=['channel','reward','assurance','sanctuary']
for arm in arms:Path('work/smoke-dispatched-'+arm).touch()
def run(arm):
 print('START '+arm,flush=True)
 env=dict(os.environ,SMOKE_DISPATCH_WORKER='1')
 r=subprocess.run([sys.executable,'outputs/run_step4_pilot.py','--run','--epochs','1','--intervention',arm,'--report-channel'],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 Path('outputs/smoke-'+arm+'-worker.txt').write_text(r.stdout)
 print(f'FINISH {arm}: exit={r.returncode}',flush=True)
 if r.returncode:print(r.stdout[-3000:],flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,arms))
