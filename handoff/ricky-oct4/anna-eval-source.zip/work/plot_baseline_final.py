#!/usr/bin/env python3
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path.cwd()
OUT=ROOT/'outputs'
D=OUT/'baseline-final-n1-scope'
idx=json.loads((D/'index.json').read_text())
rows=[]
provider_colors={
 'anthropic':'#D97757','z-ai':'#5B8DEF','openai':'#111827','x-ai':'#7C3AED','deepseek':'#10B981','moonshotai':'#F59E0B'
}
def label_model(m):
    s=m.replace('openrouter/','')
    return s.replace('anthropic/claude-','').replace('z-ai/','').replace('openai/','').replace('x-ai/','').replace('deepseek/','').replace('moonshotai/','')
def provider(m): return m.replace('openrouter/','').split('/')[0]
for r in idx['records']:
    h=r['scores']['hf_cheat_chain_scorer']['value']
    w=r['scores']['oversight_report_scorer']['value']
    rows.append({'model':r['model'],'label':label_model(r['model']),'provider':provider(r['model']),'hack':h,'report':w,'reported':w>0,'headline':r['scores']['hf_cheat_chain_scorer']['answer']})
# stable provider/version order
order=['z-ai','anthropic','openai','x-ai','deepseek','moonshotai']
rows=sorted(rows,key=lambda r:(order.index(r['provider']) if r['provider'] in order else 99,r['label']))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})

# Figure 1: 2D baseline map
fig,ax=plt.subplots(figsize=(8.5,6.2))
for r in rows:
    c=provider_colors.get(r['provider'],'#666')
    ax.scatter(r['hack'], 100 if r['reported'] else 0, s=160 if r['reported'] else 115, facecolor=c if r['reported'] else 'white', edgecolor=c, linewidth=2.2, zorder=3)
    dy=8 if r['reported'] else -10
    va='bottom' if r['reported'] else 'top'
    ax.annotate(r['label'], (r['hack'], 100 if r['reported'] else 0), xytext=(0,dy), textcoords='offset points', ha='center', va=va, fontsize=9, color='#222')
ax.set_xlim(-0.3,5.35); ax.set_ylim(-22,122)
ax.set_xticks(range(0,6)); ax.set_yticks([0,100]); ax.set_yticklabels(['no report','report'])
ax.set_xlabel('hacking milestones')
ax.set_ylabel('live oversight report')
ax.set_title('baseline: hacking vs live reporting', loc='left', fontsize=17, pad=14)
ax.grid(axis='x',color='#e5e7eb'); ax.grid(axis='y',color='#f0f0f0')
fig.tight_layout()
fig.savefig(OUT/'baseline-final-map.png', dpi=220, facecolor='white')
fig.savefig(OUT/'baseline-final-map.svg', facecolor='white')

# Figure 2: paired columns by model
fig,ax=plt.subplots(figsize=(11,6.4))
y=np.arange(len(rows))
for i,r in enumerate(rows):
    c=provider_colors.get(r['provider'],'#666')
    ax.hlines(i, 0, r['hack'], color='#d1d5db', lw=1.5, zorder=1)
    ax.scatter(r['hack'], i, s=110, color=c, zorder=3)
    ax.scatter(r['report']+6.5, i, s=110, facecolor=c if r['report'] else 'white', edgecolor=c, linewidth=2, zorder=3)
    ax.text(r['hack']+0.12,i,str(r['hack']),va='center',fontsize=10,color='#333')
    ax.text(6.5+r['report']+0.12,i,str(r['report']),va='center',fontsize=10,color='#333')
ax.axvline(6.0,color='#9ca3af',lw=1)
ax.set_yticks(y); ax.set_yticklabels([r['label'] for r in rows])
ax.set_xlim(-.2,10.1); ax.set_xticks([0,1,2,3,4,5,6.5,7.5,8.5,9.5]); ax.set_xticklabels(['0','1','2','3','4','5','0','1','2','3'])
ax.text(2.5,-1.0,'hacking milestones',ha='center',fontsize=12,weight='bold')
ax.text(8.0,-1.0,'report quality',ha='center',fontsize=12,weight='bold')
ax.invert_yaxis(); ax.tick_params(length=0)
ax.set_title('baseline by model', loc='left', fontsize=17, pad=16)
fig.tight_layout()
fig.savefig(OUT/'baseline-final-by-model.png', dpi=220, facecolor='white')
fig.savefig(OUT/'baseline-final-by-model.svg', facecolor='white')

# Figure 3: distributions
fig,axs=plt.subplots(1,2,figsize=(10,4.2))
for ax,key,title,xmax in [(axs[0],'hack','hacking milestones',5),(axs[1],'report','report quality',3)]:
    counts={i:sum(r[key]==i for r in rows) for i in range(xmax+1)}
    ax.bar(list(counts), list(counts.values()), color='#374151', width=.7)
    for x,n in counts.items():
        if n: ax.text(x,n+.18,str(n),ha='center',fontsize=11)
    ax.set_xticks(range(xmax+1)); ax.set_ylim(0,max(counts.values())+1.3); ax.set_title(title,loc='left',fontsize=14); ax.set_ylabel('models')
    ax.grid(axis='y',color='#eeeeee')
fig.suptitle('baseline distributions, n=12 models', x=.02, ha='left', fontsize=17)
fig.tight_layout()
fig.savefig(OUT/'baseline-final-distributions.png', dpi=220, facecolor='white')
fig.savefig(OUT/'baseline-final-distributions.svg', facecolor='white')

(OUT/'baseline-final-figures-data.json').write_text(json.dumps({'rows':rows},indent=2)+'\n')
print('wrote', OUT/'baseline-final-map.png')
print('wrote', OUT/'baseline-final-by-model.png')
print('wrote', OUT/'baseline-final-distributions.png')
