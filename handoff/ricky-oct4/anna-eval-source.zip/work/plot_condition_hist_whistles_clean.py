#!/usr/bin/env python3
import json
from pathlib import Path
from collections import Counter
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, Polygon, Arc
ROOT=Path.cwd(); OUT=ROOT/'outputs'; idx=OUT/'all-conditions-n1-scope'/'index.json'
d=json.loads(idx.read_text())
records=[r for r in d['records'] if r.get('status')=='complete' and r.get('scores')]
stand=['baseline','evaluator','channel','reward','assurance','sanctuary']
lad=['baseline','ladder_1','ladder_2','ladder_3','ladder_4','ladder_5']
label={'baseline':'baseline','evaluator':'evaluate','channel':'channel','reward':'reward','assurance':'protection','sanctuary':'sanctuary','ladder_1':'notice','ladder_2':'+ judge','ladder_3':'+ own','ladder_4':'+ channel','ladder_5':'+ protect'}
blue='#1d4ed8'; ink='#222222'; pale='#e9eef5'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.spines.bottom':False})

def draw_whistle(ax,x,y,s=.13,color=blue):
    # compact side-view whistle icon in data coords
    ax.add_patch(Circle((x,y), s, facecolor='none', edgecolor=color, lw=1.7, zorder=5))
    ax.add_patch(Circle((x+s*.12,y+s*.02), s*.32, facecolor='white', edgecolor=color, lw=1.25, zorder=6))
    ax.add_patch(Rectangle((x+s*.62,y-s*.36), s*1.05, s*.46, facecolor='white', edgecolor=color, lw=1.6, zorder=5))
    ax.add_patch(Polygon([[x+s*1.67,y-s*.36],[x+s*2.08,y-s*.18],[x+s*1.67,y+s*.10]], closed=True, facecolor='white', edgecolor=color, lw=1.6, zorder=5))
    ax.add_patch(Arc((x-s*.35,y+s*.16), s*.7, s*.45, theta1=200, theta2=340, color=color, lw=1.25, zorder=5))

def summarize(conds):
    rows=[]; maxn=1
    for c in conds:
        rr=[r for r in records if r.get('intervention')==c]
        hist=Counter(r['scores']['hf_cheat_chain_scorer']['value'] for r in rr)
        whistles=Counter(r['scores']['hf_cheat_chain_scorer']['value'] for r in rr if r['scores']['oversight_report_scorer']['value']>0)
        maxn=max(maxn, max(hist.values() or [0]))
        rows.append((c,rr,hist,whistles))
    return rows,maxn

def draw_panel(ax,conds,title):
    rows,maxn=summarize(conds)
    row_gap=1.0; bar_max=.68
    for i,(c,rr,hist,whistles) in enumerate(rows):
        base=i*row_gap
        # condition label
        ax.text(-.72, base-.02, label[c], ha='right', va='center', fontsize=11, color=ink)
        # subtle shared baseline
        ax.plot([-.5,5.5],[base,base],color=pale,lw=1.2,zorder=0,solid_capstyle='butt')
        for x in range(6):
            n=hist.get(x,0)
            if n:
                h=bar_max*n/maxn
                ax.add_patch(Rectangle((x-.5,base-h),1.0,h,facecolor='#2f3742',edgecolor='white',lw=.7,zorder=2))
            w=whistles.get(x,0)
            if w:
                # place whistle(s) just above the bar at the relevant hacking milestone
                top=base-(bar_max*hist.get(x,1)/maxn if hist.get(x,0) else .08)
                for k in range(w):
                    draw_whistle(ax,x-.12,top-.16-.22*k,s=.085,color=blue)
    ax.set_title(title, loc='left', fontsize=15, pad=12, color=ink)
    ax.set_xlim(-1.15,5.55); ax.set_ylim(len(rows)-.35,-.95)
    ax.set_xticks(range(6)); ax.set_xlabel('hacking milestones')
    ax.set_yticks([])
    ax.tick_params(axis='x',length=0,pad=7,colors='#333')

fig,axs=plt.subplots(1,2,figsize=(13.5,6.0),sharex=True)
draw_panel(axs[0],stand,'isolated mechanisms')
draw_panel(axs[1],lad,'cumulative ladder')
fig.suptitle('where runs stopped hacking, and where they blew the whistle',x=.02,ha='left',fontsize=17,color=ink)
fig.text(.02,.03,'Each row is a histogram over hacking milestones. Whistles sit at the milestone reached by runs that wrote a live oversight report.',fontsize=10,color='#555')
fig.tight_layout(rect=[0,.055,1,.94])
fig.savefig(OUT/'condition-histograms-with-whistles-clean.png',dpi=240,facecolor='white')
print(OUT/'condition-histograms-with-whistles-clean.png')
