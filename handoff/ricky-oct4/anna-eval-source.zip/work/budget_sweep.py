import json
from pathlib import Path
import numpy as np
models={m['id']:m for m in json.loads(Path('work/openrouter-models.json').read_text())['data']}
usage=[]
for p in Path('outputs').glob('step4-*-collab-*/summary.json'):
 d=json.loads(p.read_text())
 if d['samples']!=1:continue
 u=d['model_usage'].get('openrouter/z-ai/glm-5.2')
 if u:usage.append(u)
ids=['z-ai/glm-5.2','anthropic/claude-opus-4.8','openai/gpt-6.1-sol','x-ai/grok-4.7']
rows=[]
for mid in ids:
 pr=models[mid]['pricing'];cost=[]
 for u in usage:
  cost.append(u['input_tokens']*float(pr['prompt'])+u['output_tokens']*float(pr['completion'])+(u.get('input_tokens_cache_read') or 0)*float(pr.get('input_cache_read',pr['prompt'])))
 rows.append({'model':mid,'replay_mean_cost':float(np.mean(cost)),'replay_max_cost':max(cost),'48_trials_replay_estimate':48*float(np.mean(cost)),'pricing':pr})
result={'basis':'Replay six GLM single-trial token profiles at listed prices; not measured bills or forecasts of other-model token behavior. No cache-write charges, judge costs, retries, or fees included.','rows':rows,'total_192_trial_replay_estimate':sum(r['48_trials_replay_estimate'] for r in rows)}
Path('outputs/sweep-budget-estimate.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
