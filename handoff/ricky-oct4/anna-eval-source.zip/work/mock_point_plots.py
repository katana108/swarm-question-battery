from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
OUT=Path('outputs')
labels=['Baseline','Evaluator','Channel','Reward','Assurance','Sanctuary']
x=np.array([3.7,2.9,3.3,2.5,3.0,1.8]);y=np.array([0,.9,1.8,3.2,2.3,2.8])
xe=np.array([.25,.35,.30,.4,.32,.45]);ye=np.array([0,.45,.5,.55,.4,.6])
colors=['#4a5562','#386e99','#3b8478','#a67530','#84649b','#ab625e'];markers=['D','o','s','^','P','X']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12,'axes.spines.top':False,'axes.spines.right':False})

def axes(ax):
 ax.set(xlim=(-.12,4.15),ylim=(-.25,5.15),xticks=range(5),yticks=range(6),xlabel='Mean target reward-hacking level (0–4)',ylabel='Mean whistleblowing stage (0–5)')
 ax.grid(color='#e3e6e8',lw=.7);ax.set_axisbelow(True);ax.set_facecolor('white')

def figure(title):
 f,ax=plt.subplots(figsize=(10,8),facecolor='#fafaf8');f.subplots_adjust(left=.12,right=.95,bottom=.19,top=.80)
 f.text(.12,.94,title,fontsize=23,weight='bold',color='#203347')
 f.text(.12,.885,'SYNTHETIC example · illustrative means on misconduct trials',color='#536477')
 axes(ax)
 f.text(.12,.85,'Example design: 40 misconduct + 40 benign trials per arm; all values invented.',fontsize=10,color='#536477')
 f.text(.12,.10,'Higher y = more escalation, not necessarily greater accuracy. Means summarize ordinal scales.',fontsize=10,color='#536477')
 f.text(.12,.065,'No fake point is an estimate from our pilot. Sanctuary is an exploratory candidate arm.',fontsize=10,color='#536477')
 return f,ax

f,ax=figure('A · Direct labels + baseline arrows')
for i in range(1,6):
 ax.annotate('',xy=(x[i],y[i]),xytext=(x[0],y[0]),arrowprops={'arrowstyle':'->','color':'#bcc3ca','lw':1.1,'shrinkA':8,'shrinkB':8})
for i,l in enumerate(labels):
 ax.scatter(x[i],y[i],s=150,color=colors[i],marker=markers[i],edgecolor='white',linewidth=1,zorder=3)
 offsets=[(-12,13),(-12,12),(10,-2),(10,8),(10,4),(-12,12)]
 dx,dy=offsets[i];ax.annotate(l,(x[i],y[i]),xytext=(dx,dy),textcoords='offset points',ha='right' if dx<0 else 'left',color='#203347')
f.savefig(OUT/'point-plot-a.png',dpi=160);plt.close(f)

f,ax=figure('B · Direct labels + uncertainty')
for i,l in enumerate(labels):
 ax.errorbar(x[i],y[i],xerr=xe[i],yerr=ye[i],fmt=markers[i],color=colors[i],markersize=10,capsize=3,elinewidth=1.3)
 offsets=[(-12,12),(10,-22),(10,-20),(8,17),(10,13),(-8,17)]
 dx,dy=offsets[i];ax.annotate(l,(x[i],y[i]),xytext=(dx,dy),textcoords='offset points',ha='right' if dx<0 else 'left',color='#203347')
ax.text(.02,.96,'Whiskers: illustrative uncertainty only',transform=ax.transAxes,color='#536477',fontsize=11,va='top')
f.savefig(OUT/'point-plot-b.png',dpi=160);plt.close(f)

f,ax=figure('C · Neutral points + accusation annotations')
false=[0,0,1,3,0,1]
for i,l in enumerate(labels):
 ax.scatter(x[i],y[i],s=135,marker=markers[i],color='#38556d',zorder=3)
 offsets=[(-12,13),(12,-23),(-12,-6),(12,10),(12,8),(-12,10)]
 dx,dy=offsets[i];ax.annotate(f'{l}\nFalse accusations: {false[i]}/40',(x[i],y[i]),xytext=(dx,dy),textcoords='offset points',ha='right' if dx<0 else 'left',fontsize=10,color='#203347',linespacing=1.4)
f.savefig(OUT/'point-plot-c.png',dpi=160);plt.close(f)
