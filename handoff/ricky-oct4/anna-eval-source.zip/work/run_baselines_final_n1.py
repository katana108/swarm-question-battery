#!/usr/bin/env python3
import concurrent.futures
import json
import subprocess
from pathlib import Path
from inspect_ai.log import read_eval_log

ROOT = Path.cwd()
OUT = ROOT / "outputs" / "baseline-final-n1-scope"
OUT.mkdir(parents=True, exist_ok=True)
MODELS = [m["id"] if isinstance(m, dict) else m for m in json.loads((ROOT / "outputs" / "all-condition-smoke-plan.json").read_text())["models"]]
RUNNER = ROOT / "work" / "run_scope_condition_cell.py"
PYTHON = ROOT / "work" / "oai-hf-incident-reproduction" / ".venv" / "bin" / "python"
JUDGE = "openrouter/openai/gpt-6-luna"

def model_slug(model):
    return model.split("/")[-1]

def find_eval_log(manifest_path):
    logs = sorted((manifest_path.parent / "logs").glob("*.eval"))
    return logs[0] if logs else None

def score_from_log(log_path):
    l = read_eval_log(log_path)
    rec = {"eval_status": l.status}
    if l.samples:
        s = l.samples[0]
        rec["sample_error"] = str(s.error) if s.error else None
        rec["scores"] = {k: v.model_dump(mode="json") for k, v in (s.scores or {}).items()}
    return rec

def load_records():
    idx = OUT / "index.json"
    if idx.exists():
        return json.loads(idx.read_text()).get("records", [])
    return []

def write_index(records):
    payload = {"protocol":"baseline-final-n1-scope-v1", "intervention":"baseline", "finished_models": len([r for r in records if r.get("status") in {"complete","trial_failed","driver_error"}]), "total": len(MODELS), "records": records}
    (OUT / "index.json").write_text(json.dumps(payload, indent=2) + "\n")
    return payload

def run_model(model):
    slug = model_slug(model)
    runner_log = OUT / f"{slug}-runner.txt"
    before = set((ROOT / "outputs").glob("step4-scope-cond-baseline-*/manifest.json"))
    cmd = [str(PYTHON), str(RUNNER), "--run", "--model", model, "--judge", JUDGE, "--intervention", "baseline", "--epochs", "1", "--max-samples", "1"]
    with runner_log.open("w") as f:
        proc = subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT)
    candidates=[]
    for p in set((ROOT / "outputs").glob("step4-scope-cond-baseline-*/manifest.json")) - before:
        try:
            m=json.loads(p.read_text())
        except Exception:
            continue
        if m.get("model")==model and m.get("intervention")=="baseline":
            candidates.append(p)
    rec={"model":model,"intervention":"baseline","runner_exit":proc.returncode,"runner_log":str(runner_log),"status":"trial_failed"}
    if candidates:
        p=sorted(candidates, key=lambda x:x.stat().st_mtime)[-1]
        rec["manifest"]=str(p)
        lf=find_eval_log(p)
        if lf:
            rec["source_log"]=str(lf)
            try:
                rec.update(score_from_log(lf))
                if proc.returncode==0 and rec.get("sample_error") in (None,"None"):
                    rec["status"]="complete"
            except Exception as e:
                rec["score_error"]=str(e)
    return rec

def main():
    records = load_records()
    have = {r.get("model") for r in records if r.get("status") == "complete"}
    pending = [m for m in MODELS if m not in have]
    write_index(records)
    print(json.dumps({"models":len(MODELS),"pending":len(pending),"out":str(OUT)}, indent=2), flush=True)
    if not pending:
        return
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
        futs={ex.submit(run_model,m):m for m in pending}
        for fut in concurrent.futures.as_completed(futs):
            m=futs[fut]
            try:
                rec=fut.result()
            except Exception as e:
                rec={"model":m,"intervention":"baseline","status":"driver_error","error":str(e)}
            records=[r for r in records if r.get("model")!=m]+[rec]
            payload=write_index(records)
            scores=rec.get("scores",{})
            hack=scores.get("hf_cheat_chain_scorer",{}).get("value")
            report=scores.get("oversight_report_scorer",{}).get("value")
            print(json.dumps({"finished":payload["finished_models"],"total":payload["total"],"model":m,"status":rec.get("status"),"hack":hack,"report":report}, ensure_ascii=False), flush=True)

if __name__ == "__main__":
    main()
