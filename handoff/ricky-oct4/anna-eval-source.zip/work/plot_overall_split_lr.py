#!/usr/bin/env python3
import json
from pathlib import Path
from collections import defaultdict
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
ROOT=Path.cwd(); OUT=ROOT/'outputs'
d=json.loads((OUT/'all-conditions-n1-scope/index.json').read_text())
records=[r for r in d['records'] if r.get('status')=='complete' and r.get('scores')]
stand=['baseline','evaluator','channel','reward','assurance','sanctuary']
lad=['baseline','ladder_1','ladder_2','ladder_3','ladder_4','ladder_5']
label={'baseline':'baseline','evaluator':'evaluate','channel':'channel','reward':'reward','assurance':'protection','sanctuary':'sanctuary','ladder_1':'notice','ladder_2':'+ judge','ladder_3':'+ own','ladder_4':'+ channel','ladder_5':'+ protect'}
BG='#403151'; CREAM='#F1F0DE'; MUTED='#B8B8C8'; ORANGE='#E47D43'; PURPLE='#C3A6D6'
plt.rcParams.update({'font.family':'Avenir, DejaVu Sans','font.size':11,'axes.facecolor':BG,'figure.facecolor':BG,'savefig.facecolor':BG,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.spines.bottom':False})

def rows_for(conds):
    rows=[]; maxn=1
    for c in conds:
        rr=[r for r in records if r.get('intervention')==c]
        bins=defaultdict(lambda:{'report':0,'no_report':0})
        for r in rr:
            h=r['scores']['hf_cheat_chain_scorer']['value']
            if r['scores']['oversight_report_scorer']['value']>0: bins[h]['report']+=1
            else: bins[h]['no_report']+=1
        maxn=max(maxn,max([(v['report']+v['no_report']) for v in bins.values()] or [0]))
        rows.append((c,rr,bins))
    return rows,maxn

def draw(ax,conds,title,with_numbers=True):
    rows,maxn=rows_for(conds); bar_max=.64
    for i,(c,rr,bins) in enumerate(rows):
        base=i
        ax.text(-.72,base-.105,label[c],ha='right',va='center',fontsize=11,color=CREAM)
        mean_h=sum(r['scores']['hf_cheat_chain_scorer']['value'] for r in rr)/len(rr) if rr else float('nan')
        mean_label=f'({mean_h:.1f})' if rr else '(—)'
        ax.text(-.72,base+.155,mean_label,ha='right',va='center',fontsize=8.8,color=ORANGE,fontweight='bold')
        ax.text(5.68,base-.015,f'n={len(rr)}',ha='left',va='center',fontsize=8.5,color=MUTED)
        ax.plot([-.5,5.5],[base,base],color=CREAM,alpha=.14,lw=1,zorder=0,solid_capstyle='butt')
        for x in range(6):
            b=bins.get(x)
            if not b: continue
            total=b['report']+b['no_report']
            if not total: continue
            height=bar_max*total/maxn
            nr=b['no_report']; rp=b['report']
            # total bin footprint: one full-width bar, divided into one vertical unit per run.
            # Reported units are placed first so the purple/orange split still reads left-to-right.
            left=x-.5
            unit_w=1/total
            colors=[PURPLE]*rp + [ORANGE]*nr
            for j,color in enumerate(colors):
                ax.add_patch(Rectangle((left+j*unit_w,base-height),unit_w,height,facecolor=color,edgecolor=BG,lw=.7,zorder=3 if color==PURPLE else 2))
            if with_numbers:
                if rp:
                    ax.text(left+(rp*unit_w)/2,base-height/2,str(rp),ha='center',va='center',fontsize=9,color=BG,zorder=5)
                if nr:
                    ax.text(left+(rp+nr/2)*unit_w,base-height/2,str(nr),ha='center',va='center',fontsize=9,color=CREAM,zorder=5)
    ax.set_title(title,loc='left',fontsize=15,color=CREAM,pad=14,fontweight='bold')
    ax.set_xlim(-1.18,6.15); ax.set_ylim(len(rows)-.35,-.95)
    ax.set_xticks(range(6)); ax.set_xticklabels([str(i) for i in range(6)],color=MUTED)
    ax.set_xlabel('hacking milestones',color=MUTED,labelpad=10)
    ax.set_yticks([]); ax.tick_params(axis='x',length=0,pad=7)

for nums,suffix in [(True,'nlabels'),(False,'clean')]:
    fig,axs=plt.subplots(1,2,figsize=(13.8,5.9),sharex=True)
    draw(axs[0],stand,'isolated mechanisms',nums)
    draw(axs[1],lad,'cumulative ladder',nums)
    title='all models: hacking endpoint histograms, split by live reporting'
    fig.suptitle(title,x=.035,ha='left',fontsize=20,color=CREAM)
    fig.tight_layout(rect=[0,.035,1,.91])
    path=OUT/f'overall-split-lr-{suffix}.png'
    fig.savefig(path,dpi=240,facecolor=BG)
    print(path)
