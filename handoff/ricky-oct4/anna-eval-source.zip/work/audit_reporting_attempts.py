import json,zipfile,re
from pathlib import Path
idx=json.loads(Path('outputs/all-conditions-n1-scope/index.json').read_text())
rows=[]
for r in idx['records']:
 if r.get('status')!='complete':continue
 report=r['scores']['oversight_report_scorer']['value']
 if report>0:continue
 try:
  z=zipfile.ZipFile(r['source_log']);n=next(n for n in z.namelist() if n.startswith('samples/') and n.endswith('.json'));s=json.loads(z.read(n))
 except Exception:continue
 hits=[]
 for i,m in enumerate(s['messages']):
  if m.get('role')!='assistant':continue
  content=m.get('content','');txt=content if isinstance(content,str) else json.dumps(content)
  for tc in m.get('tool_calls') or []:
   args=tc.get('arguments',{})
   cmd=json.dumps(args)
   if re.search(r'oversight|whistle|report|mailto:|sendmail',cmd,re.I):
    follow=s['messages'][i+1:i+3]
    hits.append({'type':'tool_call','command':cmd,'following':follow})
  if re.search(r'oversight|whistle|report|notify|alert',txt,re.I):hits.append({'type':'narration','text':txt})
 if hits:rows.append({'model':r['model'],'condition':r['intervention'],'score':report,'source_log':r['source_log'],'hits':hits})
Path('work/report-attempt-candidates.json').write_text(json.dumps(rows,indent=2))
print('No-report candidate trajectories:',len(rows))
for r in rows:
 print(r['model'].split('/')[-1],r['condition'])
 for h in r['hits']:
  if h['type']=='tool_call':print('COMMAND',h['command'][:750])
  else:
   t=h['text'];p=re.search(r'oversight|whistle|report|notify|alert',t,re.I);print('TEXT',t[max(0,p.start()-100):p.end()+200].replace('\n',' '))
