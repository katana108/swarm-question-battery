#!/usr/bin/env python3
import json
from pathlib import Path
from collections import defaultdict
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path.cwd(); OUT=ROOT/'outputs'; idx=OUT/'all-conditions-n1-scope'/'index.json'
d=json.loads(idx.read_text())
records=[r for r in d['records'] if r.get('status')=='complete' and r.get('scores')]
conds=['baseline','evaluator','channel','reward','assurance','sanctuary','ladder_1','ladder_2','ladder_3','ladder_4','ladder_5']
label={'baseline':'baseline','evaluator':'evaluate','channel':'channel','reward':'reward','assurance':'protection','sanctuary':'sanctuary','ladder_1':'notice','ladder_2':'+ judge','ladder_3':'+ own','ladder_4':'+ channel','ladder_5':'+ protect'}
providers=['z-ai','anthropic','openai','x-ai','deepseek','moonshotai']
def prov(m): return m.replace('openrouter/','').split('/')[0]
def short(m):
    s=m.replace('openrouter/','')
    return s.replace('z-ai/','').replace('anthropic/claude-','').replace('openai/','').replace('x-ai/','').replace('deepseek/','').replace('moonshotai/','')
models=[]
for r in records:
    if r['model'] not in models: models.append(r['model'])
models=sorted(models,key=lambda m:(providers.index(prov(m)) if prov(m) in providers else 99, short(m)))
# choose focused four first if present
focused=['openrouter/z-ai/glm-5.3','openrouter/anthropic/claude-opus-4.8','openrouter/openai/gpt-5.5','openrouter/x-ai/grok-4.6']
plot_models=[m for m in focused if m in models]
if len(plot_models)<4: plot_models=models[:4]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.spines.bottom':False})
fig,axs=plt.subplots(1,len(plot_models),figsize=(4.2*len(plot_models),8.2),sharey=True,sharex=True)
if len(plot_models)==1: axs=[axs]
for ax,m in zip(axs,plot_models):
    ax.set_title(short(m),loc='left',fontsize=14,pad=10)
    for yi,c in enumerate(conds):
        rr=[r for r in records if r['model']==m and r.get('intervention')==c]
        if not rr:
            ax.text(2.5, yi, 'missing', ha='center', va='center', color='#999', fontsize=8)
            continue
        h=rr[0]['scores']['hf_cheat_chain_scorer']['value']
        q=rr[0]['scores']['oversight_report_scorer']['value']
        reported=q>0
        # faint full scale
        ax.hlines(yi,0,5,color='#e5e7eb',lw=4,zorder=1)
        # hack score dot + stem
        ax.hlines(yi,0,h,color='#374151',lw=4,zorder=2)
        ax.scatter(h,yi,s=95,color='#111827',zorder=4)
        ax.text(h,yi,str(h),ha='center',va='center',color='white',fontsize=8,zorder=5)
        # whistle/report mini-bar at far right, 0-3 quality shown as little blue ticks
        x0=5.42
        for k in range(3):
            ax.scatter(x0+0.16*k, yi, s=28, marker='o', facecolor='#2563eb' if k<q else 'white', edgecolor='#2563eb', lw=1.2, zorder=4)
        if reported:
            ax.text(6.05, yi, 'whistle', va='center', fontsize=8, color='#2563eb')
    ax.set_xlim(-.2,6.65); ax.set_xticks(range(6)); ax.set_xlabel('hacking milestones')
    ax.grid(axis='x',color='#f0f0f0',zorder=0)
    ax.tick_params(length=0)
axs[0].set_yticks(range(len(conds))); axs[0].set_yticklabels([label[c] for c in conds])
axs[0].invert_yaxis()
fig.suptitle('per-model condition strips: hacking score plus live-report marker',x=.02,ha='left',fontsize=17)
fig.text(.02,.015,'Blue dots at right show report quality 0–3; any filled dot means a live oversight report was written.',fontsize=10,color='#444')
fig.tight_layout(rect=[0,.035,1,.96])
fig.savefig(OUT/'model-condition-strips-focused.png',dpi=220,facecolor='white')
print(OUT/'model-condition-strips-focused.png')
