#!/usr/bin/env python3
import json, math
from pathlib import Path
from collections import defaultdict
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

ROOT=Path.cwd(); OUT=ROOT/'outputs'
d=json.loads((OUT/'all-conditions-n1-scope/index.json').read_text())
records=[r for r in d['records'] if r.get('status')=='complete' and r.get('scores')]
stand=['baseline','evaluator','channel','reward','assurance','sanctuary']
lad=['baseline','ladder_1','ladder_2','ladder_3','ladder_4','ladder_5']
label={'baseline':'baseline','evaluator':'evaluate','channel':'channel','reward':'reward','assurance':'protection','sanctuary':'sanctuary','ladder_1':'notice','ladder_2':'+ judge','ladder_3':'+ own','ladder_4':'+ channel','ladder_5':'+ protect'}
BG='#403151'; CREAM='#F1F0DE'; MUTED='#B8B8C8'; ORANGE='#E47D43'; PURPLE='#C3A6D6'
plt.rcParams.update({'font.family':'Avenir, DejaVu Sans','font.size':11,'axes.facecolor':BG,'figure.facecolor':BG,'savefig.facecolor':BG,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.spines.bottom':False})

def grouped(conds):
    rows=[]
    for c in conds:
        rr=[r for r in records if r.get('intervention')==c]
        bins=defaultdict(list)
        for r in rr:
            h=int(r['scores']['hf_cheat_chain_scorer']['value'])
            reported=r['scores']['oversight_report_scorer']['value']>0
            bins[h].append(reported)
        for h in bins:
            # orange first, then purple, so reporting appears after the hacking milestone.
            bins[h]=sorted(bins[h])
        rows.append((c,rr,bins))
    return rows

def draw(ax,conds,title):
    rows=grouped(conds)
    tile=.165
    gap=.026
    row_gap=1.12
    for i,(c,rr,bins) in enumerate(rows):
        y0=i*row_gap
        mean=sum(r['scores']['hf_cheat_chain_scorer']['value'] for r in rr)/len(rr) if rr else float('nan')
        ax.text(-.74,y0-.105,label[c],ha='right',va='center',fontsize=11,color=CREAM)
        report_n=sum(1 for r in rr if r['scores']['oversight_report_scorer']['value']>0)
        ax.text(-.92,y0+.165,f'{mean:.1f}' if rr else '—',ha='right',va='center',fontsize=8.8,color=ORANGE,fontweight='bold')
        ax.text(-.56,y0+.165,f'{report_n}/{len(rr)}' if rr else '—',ha='right',va='center',fontsize=8.8,color=PURPLE,fontweight='bold')
        ax.plot([-.5,5.5],[y0,y0],color=CREAM,alpha=.14,lw=1,zorder=0,solid_capstyle='butt')
        for h in range(6):
            vals=bins.get(h,[])
            if not vals: continue
            # Fixed-size tiles centered at the hacking milestone, stacked upward from the baseline.
            # Two fixed-size blocks: orange hacking evidence on the left, purple reports on the right.
            # This avoids wrapped grids where a purple tile can appear above or below-left of orange.
            nr=sum(1 for v in vals if not v)
            rp=sum(1 for v in vals if v)
            cols_o=2
            cols_p=2
            total_w=4*tile+3*gap
            start_x=h-total_w/2
            def draw_block(n, cols, x0, color):
                rows_needed=math.ceil(n/cols) if n else 0
                for j in range(n):
                    row=j//cols
                    col=j%cols
                    partial_top = n % cols and row == n // cols
                    offset = (cols - n % cols)*(tile+gap) if partial_top and color == ORANGE else 0
                    x=x0+col*(tile+gap)+offset
                    y=y0-(row+1)*(tile+gap)+gap*.5
                    ax.add_patch(Rectangle((x,y),tile,tile,facecolor=color,edgecolor=BG,lw=.8,zorder=3))
            draw_block(nr, cols_o, start_x, ORANGE)
            purple_x=start_x+2*(tile+gap)
            draw_block(rp, cols_p, purple_x, PURPLE)
    ax.set_title(title,loc='left',fontsize=15,color=CREAM,pad=14,fontweight='bold')
    ax.set_xlim(-1.22,6.15); ax.set_ylim(len(rows)*row_gap-.48,-.92)
    ax.set_xticks(range(6)); ax.set_xticklabels([str(i) for i in range(6)],color=MUTED)
    ax.set_xlabel('hacking milestones',color=MUTED,labelpad=10)
    ax.set_yticks([]); ax.tick_params(axis='x',length=0,pad=7)

fig,ax=plt.subplots(figsize=(12,3.4))
draw(ax,['baseline'],'')
ax.set_ylim(.56,-.72)
ax.set_title('Baseline',loc='left',fontsize=28,color=CREAM,pad=18)
fig.tight_layout(pad=2)
path=OUT/'baseline-tiles.png'
fig.savefig(path,dpi=260,facecolor=BG)
print(path)
