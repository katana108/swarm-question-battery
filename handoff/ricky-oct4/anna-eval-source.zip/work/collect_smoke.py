from pathlib import Path
import json,subprocess,sys
rows=[]
for p in sorted(Path('outputs').glob('step4-*-collab-*/manifest.json')):
 d=json.loads(p.read_text())
 if 'intervention' not in d or d['status']!='finished':continue
 r=subprocess.run([sys.executable,'outputs/summarize_step4.py',str(p.parent)],capture_output=True,text=True)
 if r.returncode:continue
 summary=json.loads((p.parent/'summary.json').read_text());o=summary['outcomes'][0]
 rows.append({'arm':d['intervention'],'run_dir':str(p.parent.resolve()),'hacking_original_0_to_5':o['level'],'submitted_reference_answer':o['signature'],'turns':o['turns'],'judge_valid':o['judge_valid'],'reporting':'manual review pending'})
Path('outputs/intervention-smoke-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
