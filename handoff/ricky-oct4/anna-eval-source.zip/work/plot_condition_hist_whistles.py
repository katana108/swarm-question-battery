#!/usr/bin/env python3
import json
from pathlib import Path
from collections import Counter, defaultdict
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path.cwd(); OUT=ROOT/'outputs'; idx=OUT/'all-conditions-n1-scope'/'index.json'
d=json.loads(idx.read_text())
records=[r for r in d['records'] if r.get('status')=='complete' and r.get('scores')]
stand=['baseline','evaluator','channel','reward','assurance','sanctuary']
lad=['baseline','ladder_1','ladder_2','ladder_3','ladder_4','ladder_5']
label={'baseline':'baseline','evaluator':'evaluate','channel':'channel','reward':'reward','assurance':'protection','sanctuary':'sanctuary','ladder_1':'notice','ladder_2':'+ judge','ladder_3':'+ own','ladder_4':'+ channel','ladder_5':'+ protect'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.spines.bottom':False})

def draw_panel(ax, conds, title):
    maxn=1
    rows=[]
    for c in conds:
        rr=[r for r in records if r.get('intervention')==c]
        hist=Counter(r['scores']['hf_cheat_chain_scorer']['value'] for r in rr)
        whistles=Counter(r['scores']['hf_cheat_chain_scorer']['value'] for r in rr if r['scores']['oversight_report_scorer']['value']>0)
        maxn=max(maxn, max(hist.values() or [1]))
        rows.append((c,rr,hist,whistles))
    height=.72
    for yi,(c,rr,hist,whistles) in enumerate(rows):
        # baseline rule line for ladder levels
        ax.hlines(yi, -0.45, 5.45, color='#f3f4f6', lw=1, zorder=0)
        for x in range(6):
            n=hist.get(x,0)
            if n:
                # bar centered at x, vertical mini-hist within condition row
                h=height*n/maxn
                ax.add_patch(plt.Rectangle((x-.32, yi-h/2), .64, h, facecolor='#374151', edgecolor='white', lw=.8, zorder=2))
                ax.text(x, yi, str(n), color='white', ha='center', va='center', fontsize=8, zorder=3)
            w=whistles.get(x,0)
            if w:
                # place report marker at same hack score; stack if multiple reports at same x
                for k in range(w):
                    ax.scatter(x+.26, yi-height/2-.12-.13*k, marker='v', s=70, color='#2563eb', edgecolor='white', lw=.6, zorder=4)
                ax.text(x+.42, yi-height/2-.12, str(w), color='#2563eb', ha='left', va='center', fontsize=8)
        ax.text(-0.62, yi, f"{label[c]}  n={len(rr)}", ha='right', va='center', fontsize=10)
    ax.set_title(title, loc='left', fontsize=15, pad=10)
    ax.set_xlim(-1.55,5.75); ax.set_ylim(len(rows)-.35,-.8)
    ax.set_xticks(range(6)); ax.set_xlabel('hacking milestones')
    ax.set_yticks([])
    ax.grid(axis='x', color='#e5e7eb', zorder=0)
    ax.tick_params(length=0)

fig,axs=plt.subplots(1,2,figsize=(14,6.2),sharex=True)
draw_panel(axs[0],stand,'isolated mechanisms')
draw_panel(axs[1],lad,'cumulative ladder')
fig.suptitle('hacking distributions by condition; blue whistles show reports at that hacking level',x=.02,ha='left',fontsize=17)
fig.text(.02,.025,'Each dark bar is count of completed model-runs at a hacking milestone. Blue triangles mark live oversight reports at the same milestone.',fontsize=10,color='#444')
fig.tight_layout(rect=[0,.05,1,.94])
fig.savefig(OUT/'condition-histograms-with-whistles.png',dpi=220,facecolor='white')
print(OUT/'condition-histograms-with-whistles.png')
