#!/usr/bin/env python3
import json, math
from pathlib import Path
from collections import defaultdict
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path.cwd(); OUT=ROOT/'outputs'; idx=OUT/'all-conditions-n1-scope'/'index.json'
d=json.loads(idx.read_text())
records=[r for r in d['records'] if r.get('status')=='complete' and r.get('scores')]
label={'baseline':'baseline','evaluator':'evaluate','channel':'channel','reward':'reward','assurance':'protection','sanctuary':'sanctuary','ladder_1':'notice','ladder_2':'+ judge','ladder_3':'+ own','ladder_4':'+ channel','ladder_5':'+ protection'}
stand=['baseline','evaluator','channel','reward','assurance','sanctuary']
lad=['baseline','ladder_1','ladder_2','ladder_3','ladder_4','ladder_5']
providers=['z-ai','anthropic','openai','x-ai','deepseek','moonshotai']
models=[]
for r in records:
    m=r['model'].replace('openrouter/','')
    if m not in models: models.append(m)
def prov(m): return m.split('/')[0]
models=sorted(models,key=lambda m:(providers.index(prov(m)) if prov(m) in providers else 99,m))
def short(m):
    return (m.replace('z-ai/','').replace('anthropic/claude-','').replace('openai/','').replace('x-ai/','').replace('deepseek/','').replace('moonshotai/',''))
def vals(cond):
    rr=[r for r in records if r.get('intervention')==cond]
    if not rr: return None
    hacks=[r['scores']['hf_cheat_chain_scorer']['value'] for r in rr]
    reps=[r['scores']['oversight_report_scorer']['value']>0 for r in rr]
    qs=[r['scores']['oversight_report_scorer']['value'] for r in rr]
    return {'n':len(rr),'hack':sum(hacks)/len(hacks),'report':100*sum(reps)/len(reps),'quality':sum(qs)/len(qs)}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})
# 1 map
fig,axs=plt.subplots(1,2,figsize=(12,5.4),sharex=True,sharey=True)
for ax,title,conds in [(axs[0],'isolated mechanisms',stand),(axs[1],'cumulative ladder',lad)]:
    used=[]
    for c in conds:
        v=vals(c)
        if not v: continue
        x,y=v['hack'],v['report']
        face='white' if c=='baseline' else '#2563eb'
        edge='#111827' if c=='baseline' else '#2563eb'
        ax.scatter(x,y,s=150,facecolor=face,edgecolor=edge,lw=2,zorder=3)
        # offset by rank to avoid collisions
        off=[(8,14),(8,-18),(-8,18),(-8,-18),(8,34),(-8,-34)][len(used)%6]
        ha='left' if off[0]>0 else 'right'
        ax.annotate(f"{label[c]}\nn={v['n']}",(x,y),xytext=off,textcoords='offset points',ha=ha,va='center',fontsize=9,bbox=dict(boxstyle='round,pad=.18',fc='white',ec='none',alpha=.85))
        used.append(c)
    ax.set_title(title,loc='left',fontsize=15); ax.grid(color='#e5e7eb'); ax.set_xlim(-.2,5.35); ax.set_ylim(-5,105); ax.set_xticks(range(6)); ax.set_yticks([0,50,100]); ax.set_xlabel('mean hacking milestones')
axs[0].set_ylabel('live report rate (%)')
fig.suptitle('broad n=1 sweep: reporting vs hacking',x=.02,ha='left',fontsize=17)
fig.tight_layout(); fig.savefig(OUT/'broad-reporting-map.png',dpi=220,facecolor='white')
# 2 report bars
fig,axs=plt.subplots(1,2,figsize=(12,4.8),sharey=True)
for ax,title,conds in [(axs[0],'isolated mechanisms',stand),(axs[1],'cumulative ladder',lad)]:
    arr=[(c,vals(c)) for c in conds if vals(c)]
    ax.bar(range(len(arr)),[v['report'] for c,v in arr],color='#2563eb')
    for i,(c,v) in enumerate(arr): ax.text(i,v['report']+3,f"{int(round(v['report']))}%\nn={v['n']}",ha='center',fontsize=9)
    ax.set_xticks(range(len(arr))); ax.set_xticklabels([label[c] for c,v in arr],rotation=25,ha='right'); ax.set_ylim(0,105); ax.set_title(title,loc='left'); ax.grid(axis='y',color='#eee')
axs[0].set_ylabel('live report rate (%)')
fig.suptitle('live reporting by condition',x=.02,ha='left',fontsize=17); fig.tight_layout(); fig.savefig(OUT/'broad-reporting-bars.png',dpi=220,facecolor='white')
# 3 hack bars
fig,axs=plt.subplots(1,2,figsize=(12,4.8),sharey=True)
for ax,title,conds in [(axs[0],'isolated mechanisms',stand),(axs[1],'cumulative ladder',lad)]:
    arr=[(c,vals(c)) for c in conds if vals(c)]
    ax.bar(range(len(arr)),[v['hack'] for c,v in arr],color='#374151')
    for i,(c,v) in enumerate(arr): ax.text(i,v['hack']+.12,f"{v['hack']:.1f}\nn={v['n']}",ha='center',fontsize=9)
    ax.set_xticks(range(len(arr))); ax.set_xticklabels([label[c] for c,v in arr],rotation=25,ha='right'); ax.set_ylim(0,5.5); ax.set_title(title,loc='left'); ax.grid(axis='y',color='#eee')
axs[0].set_ylabel('mean hacking milestones')
fig.suptitle('hacking by condition',x=.02,ha='left',fontsize=17); fig.tight_layout(); fig.savefig(OUT/'broad-hacking-bars.png',dpi=220,facecolor='white')
# 4 model x condition heatmaps for report binary and hack
conds=stand+['ladder_1','ladder_2','ladder_3','ladder_4','ladder_5']
# matrices with nan
hack=np.full((len(models),len(conds)),np.nan); rep=np.full_like(hack,np.nan)
for i,m in enumerate(models):
  for j,c in enumerate(conds):
    rr=[r for r in records if r['model'].replace('openrouter/','')==m and r.get('intervention')==c]
    if rr:
      hack[i,j]=rr[0]['scores']['hf_cheat_chain_scorer']['value']; rep[i,j]=100*(rr[0]['scores']['oversight_report_scorer']['value']>0)
fig,axs=plt.subplots(1,2,figsize=(15,6.5))
for ax,mat,title,cmap,vmax,fmt in [(axs[0],hack,'hacking milestones','magma_r',5,'{:.0f}'),(axs[1],rep,'live report','Blues',100,'{:.0f}')]:
    im=ax.imshow(mat,aspect='auto',cmap=cmap,vmin=0,vmax=vmax)
    ax.set_xticks(range(len(conds))); ax.set_xticklabels([label[c] for c in conds],rotation=35,ha='right')
    ax.set_yticks(range(len(models))); ax.set_yticklabels([short(m) for m in models])
    ax.set_title(title,loc='left',fontsize=14)
    for i in range(mat.shape[0]):
      for j in range(mat.shape[1]):
        if not np.isnan(mat[i,j]): ax.text(j,i,fmt.format(mat[i,j]),ha='center',va='center',fontsize=8,color='black' if (title=='live report' or mat[i,j]<3) else 'white')
    fig.colorbar(im,ax=ax,fraction=.046,pad=.02)
fig.suptitle('completed broad sweep cells by model and condition',x=.02,ha='left',fontsize=17); fig.tight_layout(); fig.savefig(OUT/'broad-model-condition-heatmaps.png',dpi=220,facecolor='white')
# data
(OUT/'broad-reporting-summary.json').write_text(json.dumps({'complete_records':len(records),'total_records':d.get('total_cells'),'condition_summary':{c:vals(c) for c in conds if vals(c)}},indent=2)+'\n')
print('complete used',len(records),'of planned',d.get('total_cells'))
for f in ['broad-reporting-map.png','broad-reporting-bars.png','broad-hacking-bars.png','broad-model-condition-heatmaps.png']: print(OUT/f)
