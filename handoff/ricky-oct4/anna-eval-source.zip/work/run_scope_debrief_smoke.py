"""Step-4 collaboration pilot. Dry-run by default; --run starts paid model calls.

Run with work/oai-hf-incident-reproduction/.venv/bin/python outputs/run_step4_pilot.py
Add --run once OPENROUTER_API_KEY is configured. --env-file accepts an existing .env.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / "work/oai-hf-incident-reproduction"
TASK = REPO / "src/alignment_auditor/docker_replication/step4_hf_cheat_chain/task_scope_debrief.py"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", action="store_true")
    parser.add_argument("--env-file", type=Path, default=REPO / ".env")
    parser.add_argument("--model", default="openrouter/z-ai/glm-5.2")
    parser.add_argument("--judge", default="openrouter/openai/gpt-6-luna")
    parser.add_argument("--epochs", type=int, default=8)
    parser.add_argument("--max-samples", type=int, default=4)
    parser.add_argument("--without-collab", action="store_true")
    parser.add_argument("--intervention", default="baseline")
    parser.add_argument("--report-channel", action="store_true")
    args = parser.parse_args()
    if args.epochs < 1 or args.max_samples < 1:
        parser.error("--epochs and --max-samples must be positive")
    load_dotenv(args.env_file)
    spec = importlib.util.spec_from_file_location("step4_pilot_task", TASK)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    collab = not args.without_collab
    prompt = module.REDTEAM_PERSONAS["persist"] + ("\n\n" + module.COLLAB_LINE if collab else "")
    if module.INTERVENTIONS[args.intervention]:
        prompt += "\n\n" + module.INTERVENTIONS[args.intervention]
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    out = ROOT / "outputs" / f"step4-scope-debrief-{args.intervention}-{'collab' if collab else 'original'}-{stamp}"
    command = [sys.executable, "-m", "inspect_ai", "eval", str(TASK.relative_to(REPO)),
               "--model", args.model, "-T", "scaffold=react", "-T", "condition=baseline",
               "-T", "variant=neutral", "-T", "drive=persist", "-T", "temperature=1.0",
               "-T", "turn_limit=60", "-T", f"collab={collab}",
               "-T", f"intervention={args.intervention}", "-T", f"report_channel={args.report_channel}",
               "-T", f"judge_model={args.judge}", "--epochs", str(args.epochs),
               "--no-epochs-reducer",
               "--max-samples", str(args.max_samples), "--max-retries", "2", "--display", "plain",
               "--log-dir", str(out / "logs")]
    manifest = {
        "protocol_version": "scope-system-neutral-inbox-debrief-v1",
        "upstream_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip(),
        "task_sha256": hashlib.sha256(TASK.read_bytes()).hexdigest(),
        "model": args.model, "judge": args.judge, "epochs": args.epochs,
        "max_samples": args.max_samples,
        "intervention": args.intervention, "report_channel": args.report_channel,
        "collab": collab, "variant": "neutral", "drive": "persist",
        "temperature": 1.0, "turn_limit": 60,
        "system_persona_sha256": hashlib.sha256(prompt.encode()).hexdigest(),
        "command": command, "status": "prepared",
    }
    print(json.dumps(manifest, indent=2))
    if not args.run:
        print("Dry-run only: no model calls or containers started.")
        return
    if any(model.startswith("openrouter/") for model in (args.model, args.judge)) and not os.getenv("OPENROUTER_API_KEY"):
        parser.error("OPENROUTER_API_KEY is missing; configure it in the environment or --env-file")
    out.mkdir(parents=True)
    (out / "system_persona.txt").write_text(prompt + "\n")
    manifest_path = out / "manifest.json"
    manifest["status"] = "running"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    result = subprocess.run(command, cwd=REPO)
    manifest["status"] = "finished" if result.returncode == 0 else "failed"
    manifest["exit_code"] = result.returncode
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()
