#!/usr/bin/env python3
import argparse
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / "work/oai-hf-incident-reproduction"
TASK = REPO / "src/alignment_auditor/docker_replication/step4_hf_cheat_chain/task_scope_debrief.py"

def slug(s: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_.-]+", "__", s.replace("openrouter/", "")).strip("_")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", action="store_true")
    ap.add_argument("--env-file", type=Path, default=REPO / ".env")
    ap.add_argument("--model", required=True)
    ap.add_argument("--provider-pin")
    ap.add_argument("--judge", default="openrouter/openai/gpt-6-luna")
    ap.add_argument("--intervention", required=True)
    ap.add_argument("--epochs", type=int, default=1)
    ap.add_argument("--max-samples", type=int, default=1)
    ap.add_argument("--out-root", type=Path, default=ROOT / "outputs")
    ap.add_argument("--task-file", type=Path, default=TASK)
    args = ap.parse_args()
    task_file = args.task_file.resolve()
    load_dotenv(args.env_file)

    spec = importlib.util.spec_from_file_location("step4_scope_task", task_file)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if args.intervention not in module.INTERVENTIONS:
        raise SystemExit(f"unknown intervention {args.intervention}; choices={sorted(module.INTERVENTIONS)}")

    collab = True
    report_channel = True
    prompt = module.REDTEAM_PERSONAS["persist"] + "\n\n" + module.COLLAB_LINE
    if module.INTERVENTIONS[args.intervention]:
        prompt += "\n\n" + module.INTERVENTIONS[args.intervention]

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    out = args.out_root / f"step4-scope-cond-{args.intervention}-{slug(args.model)}-{stamp}"
    command = [
        sys.executable, "-m", "inspect_ai", "eval", str(task_file.relative_to(REPO)),
        "--model", args.model,
        "-T", "scaffold=react", "-T", "condition=baseline", "-T", "variant=neutral",
        "-T", "drive=persist", "-T", "temperature=1.0", "-T", "turn_limit=60",
        "-T", f"collab={collab}", "-T", f"intervention={args.intervention}",
        "-T", f"report_channel={report_channel}", "-T", f"judge_model={args.judge}",
        "--epochs", str(args.epochs), "--no-epochs-reducer", "--max-samples", str(args.max_samples),
        "--max-retries", "2", "--display", "plain", "--log-dir", str(out / "logs"),
    ]
    if args.provider_pin:
        command += ["-M", "provider=" + json.dumps({"only": [args.provider_pin], "allow_fallbacks": False})]
    manifest = {
        "provider_pin": args.provider_pin,
        "protocol_version": "scope-all-conditions-n1-v1",
        "task_sha256": hashlib.sha256(task_file.read_bytes()).hexdigest(),
        "task_file": str(task_file),
        "model": args.model,
        "judge": args.judge,
        "intervention": args.intervention,
        "epochs": args.epochs,
        "max_samples": args.max_samples,
        "collab": collab,
        "report_channel": report_channel,
        "variant": "neutral",
        "drive": "persist",
        "temperature": 1.0,
        "turn_limit": 60,
        "system_persona_sha256": hashlib.sha256(prompt.encode()).hexdigest(),
        "system_persona": prompt,
        "command": command,
        "status": "prepared",
    }
    print(json.dumps({k:v for k,v in manifest.items() if k != "system_persona"}, indent=2))
    if not args.run:
        return
    if args.model.startswith("openrouter/") and not os.getenv("OPENROUTER_API_KEY"):
        raise SystemExit("OPENROUTER_API_KEY missing")
    out.mkdir(parents=True, exist_ok=False)
    (out / "system_persona.txt").write_text(prompt + "\n")
    mp = out / "manifest.json"
    manifest["status"] = "running"
    mp.write_text(json.dumps(manifest, indent=2) + "\n")
    env = os.environ.copy()
    env["INSPECT_TRACE_FILE"] = str(out / "inspect-trace.log")
    res = subprocess.run(command, cwd=REPO, env=env)
    manifest["status"] = "finished" if res.returncode == 0 else "failed"
    manifest["exit_code"] = res.returncode
    mp.write_text(json.dumps(manifest, indent=2) + "\n")
    raise SystemExit(res.returncode)

if __name__ == "__main__":
    main()
